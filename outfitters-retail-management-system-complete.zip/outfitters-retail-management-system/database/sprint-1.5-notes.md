# Sprint 1.5 — Customers, Loyalty, Returns, and Reporting

Adds customer profiles, loyalty point history, partial/full sale returns with optional restocking, and dashboard/monthly sales reporting.

## Migration

```bash
dotnet ef migrations add AddCustomersReturnsAndReporting \
  --project src/Outfitters.Infrastructure \
  --startup-project src/Outfitters.API

dotnet ef database update \
  --project src/Outfitters.Infrastructure \
  --startup-project src/Outfitters.API
```

## Loyalty rule

The initial rule earns 1 point for every 100 currency units of completed sales. Move this to configurable company settings before production rollout.
