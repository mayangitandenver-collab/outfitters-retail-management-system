# Sprint 1.3 — POS and Sales

Adds transactional checkout, sales history, split payments, automatic inventory deduction, receipt numbering, and ESC/POS output for network-connected XPrinter-compatible printers.

Create and apply the migration:

```bash
dotnet ef migrations add AddSalesAndPayments --project src/Outfitters.Infrastructure --startup-project src/Outfitters.API
dotnet ef database update --project src/Outfitters.Infrastructure --startup-project src/Outfitters.API
```

Printer endpoint defaults to TCP port 9100. Confirm the printer model supports raw ESC/POS over the network before use.
