# Sprint 1.2 database changes

Entity Framework will create the following new tables when a migration is generated:

- Categories
- Brands
- Products
- ProductVariants
- Inventories
- InventoryTransactions

Generate and apply the migration:

```bash
dotnet ef migrations add AddCatalogAndInventory --project src/Outfitters.Infrastructure --startup-project src/Outfitters.API
dotnet ef database update --project src/Outfitters.Infrastructure --startup-project src/Outfitters.API
```
