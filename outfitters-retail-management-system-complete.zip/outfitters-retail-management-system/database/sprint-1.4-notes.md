# Sprint 1.4 — Purchasing and Controlled Transfers

Adds suppliers, purchase orders, approvals, partial/full goods receiving, inventory posting, and two-step inter-store stock transfers.

Create and apply the migration:

```bash
dotnet ef migrations add AddPurchasingAndControlledTransfers \
  --project src/Outfitters.Infrastructure \
  --startup-project src/Outfitters.API

dotnet ef database update \
  --project src/Outfitters.Infrastructure \
  --startup-project src/Outfitters.API
```

Workflow rules:

- Purchase orders must be approved before receiving.
- Goods receipts cannot exceed outstanding ordered quantities.
- Receiving posts inventory and permanent inventory transactions atomically.
- Transfers deduct source stock at dispatch and add destination stock only at receipt.
- Dispatched transfers represent stock in transit.
