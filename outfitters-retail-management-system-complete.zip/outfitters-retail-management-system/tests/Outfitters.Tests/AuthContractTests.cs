using Outfitters.Application.Auth;
namespace Outfitters.Tests;
public sealed class AuthContractTests
{
    [Fact]
    public void LoginRequest_RetainsValues()
    {
        var request = new LoginRequest("admin", "secret");
        Assert.Equal("admin", request.Username);
        Assert.Equal("secret", request.Password);
    }
}
