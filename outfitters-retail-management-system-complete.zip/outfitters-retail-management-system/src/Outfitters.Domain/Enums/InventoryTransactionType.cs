namespace Outfitters.Domain.Enums;
public enum InventoryTransactionType
{
    OpeningBalance = 1,
    Purchase = 2,
    Sale = 3,
    Return = 4,
    AdjustmentIncrease = 5,
    AdjustmentDecrease = 6,
    TransferIn = 7,
    TransferOut = 8,
    Damage = 9,
    StockCount = 10
}
