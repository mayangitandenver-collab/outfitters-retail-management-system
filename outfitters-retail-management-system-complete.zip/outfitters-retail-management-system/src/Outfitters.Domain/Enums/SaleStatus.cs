namespace Outfitters.Domain.Enums;
public enum SaleStatus { Completed = 1, Voided = 2, Refunded = 3, PartiallyRefunded = 4 }
