namespace Outfitters.Domain.Enums;
public enum LoyaltyTransactionType { Earned = 1, Redeemed = 2, Adjusted = 3, Expired = 4, Reversed = 5 }
