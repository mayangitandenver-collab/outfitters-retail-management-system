namespace Outfitters.Domain.Enums;
public enum SaleReturnStatus { Completed = 1, Voided = 2 }
