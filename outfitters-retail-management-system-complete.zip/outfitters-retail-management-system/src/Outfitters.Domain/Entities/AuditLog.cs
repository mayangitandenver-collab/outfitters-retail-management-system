using Outfitters.Domain.Common;
namespace Outfitters.Domain.Entities;
public sealed class AuditLog : BaseEntity
{
    public Guid? UserId { get; set; }
    public Guid? StoreId { get; set; }
    public string Module { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string? EntityName { get; set; }
    public string? EntityId { get; set; }
    public string? OldValueJson { get; set; }
    public string? NewValueJson { get; set; }
    public string? IpAddress { get; set; }
}
