using Outfitters.Domain.Common;
using Outfitters.Domain.Enums;
namespace Outfitters.Domain.Entities;
public sealed class SaleReturn : BaseEntity
{
    public Guid SaleId { get; set; }
    public Sale Sale { get; set; } = null!;
    public Guid StoreId { get; set; }
    public Store Store { get; set; } = null!;
    public Guid ProcessedByUserId { get; set; }
    public User ProcessedByUser { get; set; } = null!;
    public string ReturnNumber { get; set; } = string.Empty;
    public decimal RefundTotal { get; set; }
    public string Reason { get; set; } = string.Empty;
    public SaleReturnStatus Status { get; set; } = SaleReturnStatus.Completed;
    public ICollection<SaleReturnItem> Items { get; set; } = new List<SaleReturnItem>();
}
