using Outfitters.Domain.Common;
namespace Outfitters.Domain.Entities;
public sealed class GoodsReceipt : BaseEntity
{
    public string Number { get; set; } = string.Empty;
    public Guid PurchaseOrderId { get; set; }
    public PurchaseOrder PurchaseOrder { get; set; } = null!;
    public Guid ReceivedByUserId { get; set; }
    public User ReceivedByUser { get; set; } = null!;
    public DateTime ReceivedAtUtc { get; set; }
    public string? SupplierDeliveryReference { get; set; }
    public string? Remarks { get; set; }
    public ICollection<GoodsReceiptItem> Items { get; set; } = new List<GoodsReceiptItem>();
}
