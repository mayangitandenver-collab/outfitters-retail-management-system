using Outfitters.Domain.Common;
namespace Outfitters.Domain.Entities;
public sealed class Inventory : BaseEntity
{
    public Guid StoreId { get; set; }
    public Store Store { get; set; } = null!;
    public Guid ProductVariantId { get; set; }
    public ProductVariant ProductVariant { get; set; } = null!;
    public int QuantityOnHand { get; set; }
    public int ReservedQuantity { get; set; }
    public int MinimumStock { get; set; }
    public int ReorderPoint { get; set; }
    public int AvailableQuantity => QuantityOnHand - ReservedQuantity;
}
