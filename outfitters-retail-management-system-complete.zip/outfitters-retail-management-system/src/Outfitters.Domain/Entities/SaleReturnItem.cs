using Outfitters.Domain.Common;
namespace Outfitters.Domain.Entities;
public sealed class SaleReturnItem : BaseEntity
{
    public Guid SaleReturnId { get; set; }
    public SaleReturn SaleReturn { get; set; } = null!;
    public Guid SaleItemId { get; set; }
    public SaleItem SaleItem { get; set; } = null!;
    public Guid ProductVariantId { get; set; }
    public ProductVariant ProductVariant { get; set; } = null!;
    public int Quantity { get; set; }
    public decimal UnitRefund { get; set; }
    public decimal LineRefund { get; set; }
    public bool Restock { get; set; } = true;
}
