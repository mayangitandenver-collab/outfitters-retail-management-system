using Outfitters.Domain.Common;
using Outfitters.Domain.Enums;
namespace Outfitters.Domain.Entities;
public sealed class LoyaltyTransaction : BaseEntity
{
    public Guid CustomerId { get; set; }
    public Customer Customer { get; set; } = null!;
    public LoyaltyTransactionType Type { get; set; }
    public decimal Points { get; set; }
    public decimal BalanceAfter { get; set; }
    public string? ReferenceNumber { get; set; }
    public string? Notes { get; set; }
    public Guid? CreatedByUserId { get; set; }
    public User? CreatedByUser { get; set; }
}
