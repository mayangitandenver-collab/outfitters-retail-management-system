using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Outfitters.Application.Auth;
using Outfitters.Application.Common;
using Outfitters.Domain.Entities;
using Outfitters.Infrastructure.Persistence;
namespace Outfitters.Infrastructure.Identity;
public sealed class AuthService(ApplicationDbContext db, IJwtTokenService tokens, IPasswordHasher<User> hasher, IOptions<JwtOptions> options) : IAuthService
{
    private readonly JwtOptions _options = options.Value;
    public async Task<AuthResponse?> LoginAsync(LoginRequest request, string? ipAddress, CancellationToken ct)
    {
        var username = request.Username.Trim().ToLowerInvariant();
        var user = await db.Users.Include(x => x.Role).FirstOrDefaultAsync(x => x.Username == username && x.IsActive, ct);
        if (user is null || hasher.VerifyHashedPassword(user, user.PasswordHash, request.Password) == PasswordVerificationResult.Failed) return null;
        user.LastLoginAtUtc = DateTime.UtcNow;
        return await IssueAsync(user, ipAddress, ct);
    }
    public async Task<AuthResponse?> RefreshAsync(RefreshRequest request, string? ipAddress, CancellationToken ct)
    {
        var hash = tokens.HashRefreshToken(request.RefreshToken);
        var old = await db.RefreshTokens.Include(x => x.User).ThenInclude(x => x.Role).FirstOrDefaultAsync(x => x.TokenHash == hash, ct);
        if (old is null || !old.IsActive || !old.User.IsActive) return null;
        old.RevokedAtUtc = DateTime.UtcNow;
        return await IssueAsync(old.User, ipAddress, ct);
    }
    public async Task<bool> LogoutAsync(LogoutRequest request, CancellationToken ct)
    {
        var hash = tokens.HashRefreshToken(request.RefreshToken);
        var token = await db.RefreshTokens.FirstOrDefaultAsync(x => x.TokenHash == hash, ct);
        if (token is null) return false;
        token.RevokedAtUtc = DateTime.UtcNow;
        await db.SaveChangesAsync(ct);
        return true;
    }
    private async Task<AuthResponse> IssueAsync(User user, string? ip, CancellationToken ct)
    {
        var access = tokens.CreateAccessToken(user);
        var plainRefresh = tokens.CreateRefreshToken();
        db.RefreshTokens.Add(new RefreshToken { UserId = user.Id, TokenHash = tokens.HashRefreshToken(plainRefresh), ExpiresAtUtc = DateTime.UtcNow.AddDays(_options.RefreshTokenDays), CreatedByIp = ip });
        await db.SaveChangesAsync(ct);
        return new(access.Token, plainRefresh, access.ExpiresAtUtc, new(user.Id, user.Username, $"{user.FirstName} {user.LastName}".Trim(), user.Role.Name, user.StoreId, user.MustChangePassword));
    }
}
