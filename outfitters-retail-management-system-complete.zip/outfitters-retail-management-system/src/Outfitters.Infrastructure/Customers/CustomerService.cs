using Microsoft.EntityFrameworkCore;
using Outfitters.Application.Customers;
using Outfitters.Domain.Entities;
using Outfitters.Domain.Enums;
using Outfitters.Infrastructure.Persistence;
namespace Outfitters.Infrastructure.Customers;
public sealed class CustomerService(ApplicationDbContext db) : ICustomerService
{
    public async Task<IReadOnlyCollection<CustomerResponse>> SearchAsync(Guid companyId, string? search, CancellationToken ct)
    {
        var q = db.Customers.AsNoTracking().Where(x => x.CompanyId == companyId);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim().ToLower();
            q = q.Where(x => x.CustomerNumber.ToLower().Contains(s) || x.FirstName.ToLower().Contains(s) || x.LastName.ToLower().Contains(s) || (x.Email != null && x.Email.ToLower().Contains(s)) || (x.Phone != null && x.Phone.Contains(s)));
        }
        return (await q.OrderBy(x => x.LastName).ThenBy(x => x.FirstName).Take(200).ToListAsync(ct)).Select(Map).ToList();
    }
    public async Task<CustomerResponse?> GetAsync(Guid id, CancellationToken ct) { var x = await db.Customers.AsNoTracking().SingleOrDefaultAsync(v => v.Id == id, ct); return x is null ? null : Map(x); }
    public async Task<CustomerResponse> CreateAsync(CreateCustomerRequest r, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(r.FirstName) || string.IsNullOrWhiteSpace(r.LastName)) throw new ArgumentException("Customer first and last name are required.");
        if (!await db.Companies.AnyAsync(x => x.Id == r.CompanyId, ct)) throw new KeyNotFoundException("Company not found.");
        var count = await db.Customers.IgnoreQueryFilters().CountAsync(x => x.CompanyId == r.CompanyId, ct) + 1;
        var x = new Customer { CompanyId = r.CompanyId, CustomerNumber = $"CUS-{count:000000}", FirstName = r.FirstName.Trim(), LastName = r.LastName.Trim(), Email = r.Email?.Trim(), Phone = r.Phone?.Trim(), BirthDate = r.BirthDate };
        db.Customers.Add(x); await db.SaveChangesAsync(ct); return Map(x);
    }
    public async Task<CustomerResponse> UpdateAsync(Guid id, UpdateCustomerRequest r, CancellationToken ct)
    {
        var x = await db.Customers.SingleOrDefaultAsync(v => v.Id == id, ct) ?? throw new KeyNotFoundException("Customer not found.");
        x.FirstName = r.FirstName.Trim(); x.LastName = r.LastName.Trim(); x.Email = r.Email?.Trim(); x.Phone = r.Phone?.Trim(); x.BirthDate = r.BirthDate; x.IsActive = r.IsActive;
        await db.SaveChangesAsync(ct); return Map(x);
    }
    public async Task<LoyaltyTransactionResponse> AdjustLoyaltyAsync(Guid customerId, AdjustLoyaltyRequest r, CancellationToken ct)
    {
        if (r.Points == 0) throw new ArgumentException("Points adjustment cannot be zero.");
        var x = await db.Customers.SingleOrDefaultAsync(v => v.Id == customerId, ct) ?? throw new KeyNotFoundException("Customer not found.");
        if (x.LoyaltyPointsBalance + r.Points < 0) throw new InvalidOperationException("Loyalty points balance cannot be negative.");
        x.LoyaltyPointsBalance += r.Points;
        var t = new LoyaltyTransaction { CustomerId = customerId, Type = LoyaltyTransactionType.Adjusted, Points = r.Points, BalanceAfter = x.LoyaltyPointsBalance, Notes = r.Notes.Trim(), CreatedByUserId = r.CreatedByUserId };
        db.LoyaltyTransactions.Add(t); await db.SaveChangesAsync(ct); return Map(t);
    }
    public async Task<IReadOnlyCollection<LoyaltyTransactionResponse>> GetLoyaltyHistoryAsync(Guid customerId, CancellationToken ct) => (await db.LoyaltyTransactions.AsNoTracking().Where(x => x.CustomerId == customerId).OrderByDescending(x => x.CreatedAtUtc).Take(500).ToListAsync(ct)).Select(Map).ToList();
    private static CustomerResponse Map(Customer x) => new(x.Id,x.CustomerNumber,x.FirstName,x.LastName,x.Email,x.Phone,x.BirthDate,x.LoyaltyPointsBalance,x.IsActive);
    private static LoyaltyTransactionResponse Map(LoyaltyTransaction x) => new(x.Id,x.Type,x.Points,x.BalanceAfter,x.ReferenceNumber,x.Notes,x.CreatedAtUtc);
}
