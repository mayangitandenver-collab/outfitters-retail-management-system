using Microsoft.EntityFrameworkCore;
using Outfitters.Application.Reporting;
using Outfitters.Domain.Enums;
using Outfitters.Infrastructure.Persistence;
namespace Outfitters.Infrastructure.Reporting;
public sealed class ReportingService(ApplicationDbContext db) : IReportingService
{
    public async Task<DashboardSummaryResponse> GetDashboardAsync(Guid storeId, CancellationToken ct)
    {
        var today = DateTime.UtcNow.Date; var month = new DateTime(today.Year,today.Month,1,0,0,0,DateTimeKind.Utc);
        var todaySales = await db.Sales.Where(x => x.StoreId == storeId && x.Status == SaleStatus.Completed && x.CreatedAtUtc >= today).SumAsync(x => (decimal?)x.GrandTotal, ct) ?? 0;
        var monthSales = await db.Sales.Where(x => x.StoreId == storeId && x.Status == SaleStatus.Completed && x.CreatedAtUtc >= month).SumAsync(x => (decimal?)x.GrandTotal, ct) ?? 0;
        var transactions = await db.Sales.CountAsync(x => x.StoreId == storeId && x.Status == SaleStatus.Completed && x.CreatedAtUtc >= today, ct);
        var lowStock = await db.Inventories.CountAsync(x => x.StoreId == storeId && x.QuantityOnHand - x.ReservedQuantity <= x.ReorderPoint, ct);
        var inventoryValue = await db.Inventories.Where(x => x.StoreId == storeId).SumAsync(x => (decimal?)(x.QuantityOnHand * x.ProductVariant.CostPrice), ct) ?? 0;
        var refunds = await db.SaleReturns.Where(x => x.StoreId == storeId && x.Status == SaleReturnStatus.Completed && x.CreatedAtUtc >= month).SumAsync(x => (decimal?)x.RefundTotal, ct) ?? 0;
        return new(todaySales,monthSales,transactions,lowStock,inventoryValue,refunds);
    }
    public async Task<IReadOnlyCollection<MonthlySalesPoint>> GetMonthlySalesAsync(Guid storeId, int year, CancellationToken ct)
    {
        var from = new DateTime(year,1,1,0,0,0,DateTimeKind.Utc); var to = from.AddYears(1);
        var sales = await db.Sales.AsNoTracking().Where(x => x.StoreId == storeId && x.Status == SaleStatus.Completed && x.CreatedAtUtc >= from && x.CreatedAtUtc < to)
            .GroupBy(x => x.CreatedAtUtc.Month).Select(g => new { Month = g.Key, Gross = g.Sum(x => x.Subtotal), Discounts = g.Sum(x => x.DiscountTotal), Tax = g.Sum(x => x.TaxTotal), Net = g.Sum(x => x.GrandTotal), Transactions = g.Count(), Units = g.SelectMany(x => x.Items).Sum(i => i.Quantity) }).ToListAsync(ct);
        var returns = await db.SaleReturns.AsNoTracking().Where(x => x.StoreId == storeId && x.Status == SaleReturnStatus.Completed && x.CreatedAtUtc >= from && x.CreatedAtUtc < to).GroupBy(x => x.CreatedAtUtc.Month).Select(g => new { Month = g.Key, Refunds = g.Sum(x => x.RefundTotal) }).ToDictionaryAsync(x => x.Month,x => x.Refunds,ct);
        return Enumerable.Range(1,12).Select(m => { var x=sales.SingleOrDefault(v=>v.Month==m); return new MonthlySalesPoint(year,m,new DateTime(year,m,1).ToString("MMM"),x?.Gross??0,x?.Discounts??0,x?.Tax??0,x?.Net??0,returns.GetValueOrDefault(m),x?.Transactions??0,x?.Units??0); }).ToList();
    }
    public async Task<IReadOnlyCollection<TopProductResponse>> GetTopProductsAsync(Guid storeId, DateTime fromUtc, DateTime toUtc, int take, CancellationToken ct) => await db.SaleItems.AsNoTracking().Where(i => i.Sale.StoreId == storeId && i.Sale.Status == SaleStatus.Completed && i.Sale.CreatedAtUtc >= fromUtc && i.Sale.CreatedAtUtc < toUtc).GroupBy(i => new { i.ProductVariantId, i.ProductNameSnapshot, i.VariantSnapshot }).Select(g => new TopProductResponse(g.Key.ProductVariantId,g.Key.ProductNameSnapshot,g.Key.VariantSnapshot,g.Sum(x=>x.Quantity),g.Sum(x=>x.LineTotal))).OrderByDescending(x=>x.NetSales).Take(Math.Clamp(take,1,100)).ToListAsync(ct);
    public async Task<IReadOnlyCollection<PaymentSummaryResponse>> GetPaymentSummaryAsync(Guid storeId, DateTime fromUtc, DateTime toUtc, CancellationToken ct) => await db.Payments.AsNoTracking().Where(x => x.Sale.StoreId == storeId && x.Sale.Status == SaleStatus.Completed && x.Sale.CreatedAtUtc >= fromUtc && x.Sale.CreatedAtUtc < toUtc).GroupBy(x => x.Method).Select(g => new PaymentSummaryResponse(g.Key.ToString(),g.Sum(x=>x.Amount),g.Select(x=>x.SaleId).Distinct().Count())).OrderByDescending(x=>x.Amount).ToListAsync(ct);
}
