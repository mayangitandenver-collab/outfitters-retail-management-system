using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Outfitters.Application.Auth;
using Outfitters.Application.Common;
using Outfitters.Application.Catalog;
using Outfitters.Infrastructure.Catalog;
using Outfitters.Domain.Entities;
using Outfitters.Infrastructure.Identity;
using Outfitters.Infrastructure.Persistence;
using Outfitters.Application.Sales;
using Outfitters.Infrastructure.Sales;
using Outfitters.Application.Purchasing;
using Outfitters.Infrastructure.Purchasing;
using Outfitters.Application.Customers;
using Outfitters.Infrastructure.Customers;
using Outfitters.Application.Returns;
using Outfitters.Infrastructure.Returns;
using Outfitters.Application.Reporting;
using Outfitters.Infrastructure.Reporting;
namespace Outfitters.Infrastructure;
public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration config)
    {
        services.Configure<JwtOptions>(config.GetSection(JwtOptions.SectionName));
        services.AddDbContext<ApplicationDbContext>(o => o.UseNpgsql(config.GetConnectionString("DefaultConnection")));
        services.AddScoped<IJwtTokenService, JwtTokenService>();
        services.AddScoped<IAuthService, AuthService>();
        services.AddScoped<ICatalogService, CatalogService>();
        services.AddScoped<ISalesService, SalesService>();
        services.AddScoped<IReceiptPrinter, NetworkEscPosPrinter>();
        services.AddScoped<IPurchasingService, PurchasingService>();
        services.AddScoped<ICustomerService, CustomerService>();
        services.AddScoped<IReturnService, ReturnService>();
        services.AddScoped<IReportingService, ReportingService>();
        services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();
        services.AddHealthChecks().AddNpgSql(config.GetConnectionString("DefaultConnection")!);
        return services;
    }
}
