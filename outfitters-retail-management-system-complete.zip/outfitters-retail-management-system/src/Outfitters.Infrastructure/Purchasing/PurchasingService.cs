using Microsoft.EntityFrameworkCore;
using Outfitters.Application.Purchasing;
using Outfitters.Domain.Entities;
using Outfitters.Domain.Enums;
using Outfitters.Infrastructure.Persistence;
namespace Outfitters.Infrastructure.Purchasing;
public sealed class PurchasingService(ApplicationDbContext db) : IPurchasingService
{
    public async Task<IReadOnlyCollection<SupplierResponse>> GetSuppliersAsync(Guid companyId, CancellationToken ct) =>
        await db.Suppliers.AsNoTracking().Where(x => x.CompanyId == companyId).OrderBy(x => x.Name)
            .Select(x => new SupplierResponse(x.Id, x.CompanyId, x.Code, x.Name, x.ContactPerson, x.Phone, x.Email, x.PaymentTerms, x.IsActive)).ToListAsync(ct);

    public async Task<SupplierResponse> CreateSupplierAsync(SupplierRequest r, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(r.Code) || string.IsNullOrWhiteSpace(r.Name)) throw new InvalidOperationException("Supplier code and name are required.");
        var entity = new Supplier { CompanyId = r.CompanyId, Code = r.Code.Trim().ToUpperInvariant(), Name = r.Name.Trim(), ContactPerson = r.ContactPerson?.Trim(), Phone = r.Phone?.Trim(), Email = r.Email?.Trim(), TaxIdentificationNumber = r.TaxIdentificationNumber?.Trim(), Address = r.Address?.Trim(), PaymentTerms = r.PaymentTerms?.Trim() };
        db.Suppliers.Add(entity); await db.SaveChangesAsync(ct);
        return new(entity.Id, entity.CompanyId, entity.Code, entity.Name, entity.ContactPerson, entity.Phone, entity.Email, entity.PaymentTerms, entity.IsActive);
    }

    public async Task<PurchaseOrderResponse> CreatePurchaseOrderAsync(CreatePurchaseOrderRequest r, CancellationToken ct)
    {
        if (r.Items.Count == 0) throw new InvalidOperationException("At least one purchase-order item is required.");
        if (r.Items.Any(x => x.Quantity <= 0 || x.UnitCost < 0)) throw new InvalidOperationException("Quantities must be positive and costs cannot be negative.");
        var supplier = await db.Suppliers.SingleOrDefaultAsync(x => x.Id == r.SupplierId && x.IsActive, ct) ?? throw new InvalidOperationException("Supplier was not found or is inactive.");
        _ = await db.Stores.SingleOrDefaultAsync(x => x.Id == r.StoreId, ct) ?? throw new InvalidOperationException("Store was not found.");
        var variantIds = r.Items.Select(x => x.ProductVariantId).Distinct().ToArray();
        var variants = await db.ProductVariants.Include(x => x.Product).Where(x => variantIds.Contains(x.Id)).ToDictionaryAsync(x => x.Id, ct);
        if (variants.Count != variantIds.Length) throw new InvalidOperationException("One or more product variants were not found.");
        var number = await NextNumberAsync("PO", r.StoreId, ct);
        var po = new PurchaseOrder { Number = number, SupplierId = supplier.Id, StoreId = r.StoreId, CreatedByUserId = r.CreatedByUserId, OrderDateUtc = DateTime.UtcNow, ExpectedDeliveryUtc = r.ExpectedDeliveryUtc, TaxTotal = r.TaxTotal, DiscountTotal = r.DiscountTotal, Notes = r.Notes?.Trim() };
        foreach (var i in r.Items)
        {
            var line = i.Quantity * i.UnitCost;
            po.Items.Add(new PurchaseOrderItem { ProductVariantId = i.ProductVariantId, OrderedQuantity = i.Quantity, UnitCost = i.UnitCost, LineTotal = line });
            po.Subtotal += line;
        }
        po.GrandTotal = po.Subtotal + po.TaxTotal - po.DiscountTotal;
        if (po.GrandTotal < 0) throw new InvalidOperationException("Grand total cannot be negative.");
        db.PurchaseOrders.Add(po); await db.SaveChangesAsync(ct);
        return await GetPurchaseOrderAsync(po.Id, ct) ?? throw new InvalidOperationException("Purchase order could not be reloaded.");
    }

    public async Task<PurchaseOrderResponse?> GetPurchaseOrderAsync(Guid id, CancellationToken ct)
    {
        var po = await db.PurchaseOrders.AsNoTracking().Include(x => x.Supplier).Include(x => x.Items).ThenInclude(x => x.ProductVariant).ThenInclude(x => x.Product).SingleOrDefaultAsync(x => x.Id == id, ct);
        return po is null ? null : Map(po);
    }

    public async Task<IReadOnlyCollection<PurchaseOrderResponse>> GetPurchaseOrdersAsync(Guid storeId, CancellationToken ct)
    {
        var items = await db.PurchaseOrders.AsNoTracking().Include(x => x.Supplier).Include(x => x.Items).ThenInclude(x => x.ProductVariant).ThenInclude(x => x.Product).Where(x => x.StoreId == storeId).OrderByDescending(x => x.CreatedAtUtc).Take(500).ToListAsync(ct);
        return items.Select(Map).ToList();
    }

    public async Task<PurchaseOrderResponse> ApprovePurchaseOrderAsync(Guid id, CancellationToken ct)
    {
        var po = await db.PurchaseOrders.SingleOrDefaultAsync(x => x.Id == id, ct) ?? throw new InvalidOperationException("Purchase order was not found.");
        if (po.Status is not (PurchaseOrderStatus.Draft or PurchaseOrderStatus.Submitted)) throw new InvalidOperationException("Only draft or submitted purchase orders can be approved.");
        po.Status = PurchaseOrderStatus.Approved; await db.SaveChangesAsync(ct);
        return await GetPurchaseOrderAsync(id, ct) ?? throw new InvalidOperationException("Purchase order could not be reloaded.");
    }

    public async Task<GoodsReceiptResponse> ReceivePurchaseOrderAsync(Guid id, ReceivePurchaseOrderRequest r, CancellationToken ct)
    {
        if (r.Items.Count == 0) throw new InvalidOperationException("At least one received item is required.");
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var po = await db.PurchaseOrders.Include(x => x.Items).SingleOrDefaultAsync(x => x.Id == id, ct) ?? throw new InvalidOperationException("Purchase order was not found.");
        if (po.Status is PurchaseOrderStatus.Cancelled or PurchaseOrderStatus.Received or PurchaseOrderStatus.Draft) throw new InvalidOperationException("This purchase order cannot be received.");
        var requestedIds = r.Items.Select(x => x.PurchaseOrderItemId).Distinct().ToArray();
        if (requestedIds.Length != r.Items.Count) throw new InvalidOperationException("Duplicate purchase-order items are not allowed.");
        var receipt = new GoodsReceipt { Number = await NextNumberAsync("GR", po.StoreId, ct), PurchaseOrderId = po.Id, ReceivedByUserId = r.ReceivedByUserId, ReceivedAtUtc = DateTime.UtcNow, SupplierDeliveryReference = r.SupplierDeliveryReference?.Trim(), Remarks = r.Remarks?.Trim() };
        foreach (var item in r.Items)
        {
            if (item.QuantityReceived <= 0) throw new InvalidOperationException("Received quantities must be positive.");
            var poItem = po.Items.SingleOrDefault(x => x.Id == item.PurchaseOrderItemId) ?? throw new InvalidOperationException("A received item does not belong to this purchase order.");
            if (poItem.ReceivedQuantity + item.QuantityReceived > poItem.OrderedQuantity) throw new InvalidOperationException("Received quantity exceeds the outstanding ordered quantity.");
            var cost = item.UnitCost ?? poItem.UnitCost;
            poItem.ReceivedQuantity += item.QuantityReceived;
            receipt.Items.Add(new GoodsReceiptItem { PurchaseOrderItemId = poItem.Id, QuantityReceived = item.QuantityReceived, UnitCost = cost });
            var inventory = await db.Inventories.SingleOrDefaultAsync(x => x.StoreId == po.StoreId && x.ProductVariantId == poItem.ProductVariantId, ct);
            if (inventory is null) { inventory = new Inventory { StoreId = po.StoreId, ProductVariantId = poItem.ProductVariantId }; db.Inventories.Add(inventory); }
            inventory.QuantityOnHand += item.QuantityReceived;
            db.InventoryTransactions.Add(new InventoryTransaction { StoreId = po.StoreId, ProductVariantId = poItem.ProductVariantId, Type = InventoryTransactionType.Purchase, QuantityChange = item.QuantityReceived, QuantityAfter = inventory.QuantityOnHand, ReferenceNumber = receipt.Number, Remarks = r.Remarks?.Trim(), CreatedByUserId = r.ReceivedByUserId });
        }
        po.Status = po.Items.All(x => x.ReceivedQuantity == x.OrderedQuantity) ? PurchaseOrderStatus.Received : PurchaseOrderStatus.PartiallyReceived;
        db.GoodsReceipts.Add(receipt); await db.SaveChangesAsync(ct); await tx.CommitAsync(ct);
        return new(receipt.Id, receipt.Number, receipt.PurchaseOrderId, receipt.ReceivedAtUtc, receipt.SupplierDeliveryReference, receipt.Remarks);
    }

    public async Task<StockTransferResponse> CreateStockTransferAsync(CreateStockTransferRequest r, CancellationToken ct)
    {
        if (r.SourceStoreId == r.DestinationStoreId) throw new InvalidOperationException("Source and destination stores must be different.");
        if (r.Items.Count == 0 || r.Items.Any(x => x.Quantity <= 0)) throw new InvalidOperationException("At least one item with a positive quantity is required.");
        var transfer = new StockTransfer { Number = await NextNumberAsync("TR", r.SourceStoreId, ct), SourceStoreId = r.SourceStoreId, DestinationStoreId = r.DestinationStoreId, CreatedByUserId = r.CreatedByUserId, Notes = r.Notes?.Trim() };
        foreach (var i in r.Items.GroupBy(x => x.ProductVariantId).Select(g => new { ProductVariantId = g.Key, Quantity = g.Sum(x => x.Quantity) })) transfer.Items.Add(new StockTransferItem { ProductVariantId = i.ProductVariantId, Quantity = i.Quantity });
        db.StockTransfers.Add(transfer); await db.SaveChangesAsync(ct); return await GetStockTransferAsync(transfer.Id, ct) ?? throw new InvalidOperationException("Transfer could not be reloaded.");
    }

    public async Task<StockTransferResponse> DispatchStockTransferAsync(Guid id, Guid userId, CancellationToken ct)
    {
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var transfer = await db.StockTransfers.Include(x => x.Items).SingleOrDefaultAsync(x => x.Id == id, ct) ?? throw new InvalidOperationException("Transfer was not found.");
        if (transfer.Status != StockTransferStatus.Draft) throw new InvalidOperationException("Only draft transfers can be dispatched.");
        foreach (var item in transfer.Items)
        {
            var inventory = await db.Inventories.SingleOrDefaultAsync(x => x.StoreId == transfer.SourceStoreId && x.ProductVariantId == item.ProductVariantId, ct) ?? throw new InvalidOperationException("Source inventory is missing.");
            if (inventory.AvailableQuantity < item.Quantity) throw new InvalidOperationException("Insufficient available stock to dispatch transfer.");
            inventory.QuantityOnHand -= item.Quantity;
            db.InventoryTransactions.Add(new InventoryTransaction { StoreId = transfer.SourceStoreId, ProductVariantId = item.ProductVariantId, Type = InventoryTransactionType.TransferOut, QuantityChange = -item.Quantity, QuantityAfter = inventory.QuantityOnHand, ReferenceNumber = transfer.Number, CreatedByUserId = userId });
        }
        transfer.Status = StockTransferStatus.Dispatched; transfer.DispatchedAtUtc = DateTime.UtcNow; transfer.DispatchedByUserId = userId;
        await db.SaveChangesAsync(ct); await tx.CommitAsync(ct); return await GetStockTransferAsync(id, ct) ?? throw new InvalidOperationException("Transfer could not be reloaded.");
    }

    public async Task<StockTransferResponse> ReceiveStockTransferAsync(Guid id, Guid userId, CancellationToken ct)
    {
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var transfer = await db.StockTransfers.Include(x => x.Items).SingleOrDefaultAsync(x => x.Id == id, ct) ?? throw new InvalidOperationException("Transfer was not found.");
        if (transfer.Status != StockTransferStatus.Dispatched) throw new InvalidOperationException("Only dispatched transfers can be received.");
        foreach (var item in transfer.Items)
        {
            var inventory = await db.Inventories.SingleOrDefaultAsync(x => x.StoreId == transfer.DestinationStoreId && x.ProductVariantId == item.ProductVariantId, ct);
            if (inventory is null) { inventory = new Inventory { StoreId = transfer.DestinationStoreId, ProductVariantId = item.ProductVariantId }; db.Inventories.Add(inventory); }
            inventory.QuantityOnHand += item.Quantity;
            db.InventoryTransactions.Add(new InventoryTransaction { StoreId = transfer.DestinationStoreId, ProductVariantId = item.ProductVariantId, Type = InventoryTransactionType.TransferIn, QuantityChange = item.Quantity, QuantityAfter = inventory.QuantityOnHand, ReferenceNumber = transfer.Number, CreatedByUserId = userId });
        }
        transfer.Status = StockTransferStatus.Received; transfer.ReceivedAtUtc = DateTime.UtcNow; transfer.ReceivedByUserId = userId;
        await db.SaveChangesAsync(ct); await tx.CommitAsync(ct); return await GetStockTransferAsync(id, ct) ?? throw new InvalidOperationException("Transfer could not be reloaded.");
    }

    public async Task<StockTransferResponse?> GetStockTransferAsync(Guid id, CancellationToken ct)
    {
        var x = await db.StockTransfers.AsNoTracking().Include(t => t.Items).SingleOrDefaultAsync(t => t.Id == id, ct);
        return x is null ? null : new(x.Id, x.Number, x.SourceStoreId, x.DestinationStoreId, x.Status, x.DispatchedAtUtc, x.ReceivedAtUtc, x.Notes, x.Items.Select(i => new StockTransferItemRequest(i.ProductVariantId, i.Quantity)).ToList());
    }

    private async Task<string> NextNumberAsync(string prefix, Guid storeId, CancellationToken ct)
    {
        var date = DateTime.UtcNow.ToString("yyyyMMdd");
        int count = prefix switch
        {
            "PO" => await db.PurchaseOrders.IgnoreQueryFilters().CountAsync(x => x.StoreId == storeId && x.CreatedAtUtc.Date == DateTime.UtcNow.Date, ct),
            "GR" => await db.GoodsReceipts.IgnoreQueryFilters().CountAsync(x => x.CreatedAtUtc.Date == DateTime.UtcNow.Date, ct),
            _ => await db.StockTransfers.IgnoreQueryFilters().CountAsync(x => x.SourceStoreId == storeId && x.CreatedAtUtc.Date == DateTime.UtcNow.Date, ct)
        };
        return $"{prefix}-{date}-{count + 1:0000}";
    }

    private static PurchaseOrderResponse Map(PurchaseOrder x) => new(x.Id, x.Number, x.SupplierId, x.Supplier.Name, x.StoreId, x.OrderDateUtc, x.ExpectedDeliveryUtc, x.Status, x.Subtotal, x.TaxTotal, x.DiscountTotal, x.GrandTotal, x.Notes, x.Items.Select(i => new PurchaseOrderItemResponse(i.Id, i.ProductVariantId, i.ProductVariant.Product.Name, $"{i.ProductVariant.Color} / {i.ProductVariant.Size}", i.OrderedQuantity, i.ReceivedQuantity, i.UnitCost, i.LineTotal)).ToList());
}
