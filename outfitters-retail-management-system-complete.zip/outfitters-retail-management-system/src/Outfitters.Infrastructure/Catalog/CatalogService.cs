using Microsoft.EntityFrameworkCore;
using Outfitters.Application.Catalog;
using Outfitters.Domain.Entities;
using Outfitters.Domain.Enums;
using Outfitters.Infrastructure.Persistence;
namespace Outfitters.Infrastructure.Catalog;
public sealed class CatalogService(ApplicationDbContext db) : ICatalogService
{
    public async Task<IReadOnlyCollection<CategoryResponse>> GetCategoriesAsync(Guid companyId, CancellationToken ct) =>
        await db.Categories.AsNoTracking().Where(x => x.CompanyId == companyId).OrderBy(x => x.DisplayOrder).ThenBy(x => x.Name)
            .Select(x => new CategoryResponse(x.Id, x.CompanyId, x.Name, x.Slug, x.ParentCategoryId, x.DisplayOrder, x.IsActive)).ToListAsync(ct);

    public async Task<CategoryResponse> CreateCategoryAsync(CreateCategoryRequest r, CancellationToken ct)
    {
        var name = Required(r.Name, nameof(r.Name), 120); var slug = Slugify(name);
        if (!await db.Companies.AnyAsync(x => x.Id == r.CompanyId, ct)) throw new KeyNotFoundException("Company not found.");
        if (r.ParentCategoryId.HasValue && !await db.Categories.AnyAsync(x => x.Id == r.ParentCategoryId && x.CompanyId == r.CompanyId, ct)) throw new KeyNotFoundException("Parent category not found.");
        if (await db.Categories.AnyAsync(x => x.CompanyId == r.CompanyId && x.Slug == slug, ct)) throw new InvalidOperationException("A category with this name already exists.");
        var e = new Category { CompanyId = r.CompanyId, Name = name, Slug = slug, ParentCategoryId = r.ParentCategoryId, DisplayOrder = r.DisplayOrder };
        db.Categories.Add(e); await db.SaveChangesAsync(ct);
        return new(e.Id, e.CompanyId, e.Name, e.Slug, e.ParentCategoryId, e.DisplayOrder, e.IsActive);
    }

    public async Task<IReadOnlyCollection<BrandResponse>> GetBrandsAsync(Guid companyId, CancellationToken ct) =>
        await db.Brands.AsNoTracking().Where(x => x.CompanyId == companyId).OrderBy(x => x.Name)
            .Select(x => new BrandResponse(x.Id, x.CompanyId, x.Name, x.Description, x.LogoUrl, x.IsActive)).ToListAsync(ct);

    public async Task<BrandResponse> CreateBrandAsync(CreateBrandRequest r, CancellationToken ct)
    {
        var name = Required(r.Name, nameof(r.Name), 120);
        if (!await db.Companies.AnyAsync(x => x.Id == r.CompanyId, ct)) throw new KeyNotFoundException("Company not found.");
        if (await db.Brands.AnyAsync(x => x.CompanyId == r.CompanyId && x.Name.ToLower() == name.ToLower(), ct)) throw new InvalidOperationException("A brand with this name already exists.");
        var e = new Brand { CompanyId = r.CompanyId, Name = name, Description = r.Description?.Trim(), LogoUrl = r.LogoUrl?.Trim() };
        db.Brands.Add(e); await db.SaveChangesAsync(ct); return new(e.Id, e.CompanyId, e.Name, e.Description, e.LogoUrl, e.IsActive);
    }

    public async Task<IReadOnlyCollection<ProductResponse>> GetProductsAsync(Guid companyId, string? search, CancellationToken ct)
    {
        var q = db.Products.AsNoTracking().Include(x => x.Variants).Where(x => x.CompanyId == companyId);
        if (!string.IsNullOrWhiteSpace(search)) { var s = search.Trim().ToLower(); q = q.Where(x => x.Name.ToLower().Contains(s) || x.Sku.ToLower().Contains(s) || x.Variants.Any(v => v.Barcode == search || v.VariantSku.ToLower().Contains(s))); }
        var items = await q.OrderBy(x => x.Name).ToListAsync(ct);
        return items.Select(MapProduct).ToList();
    }

    public async Task<ProductResponse?> GetProductAsync(Guid id, CancellationToken ct)
    {
        var x = await db.Products.AsNoTracking().Include(p => p.Variants).SingleOrDefaultAsync(p => p.Id == id, ct); return x is null ? null : MapProduct(x);
    }

    public async Task<ProductResponse> CreateProductAsync(CreateProductRequest r, CancellationToken ct)
    {
        var sku = Required(r.Sku, nameof(r.Sku), 60).ToUpperInvariant(); var name = Required(r.Name, nameof(r.Name), 180);
        if (r.Variants is null || r.Variants.Count == 0) throw new ArgumentException("At least one product variant is required.");
        if (!await db.Companies.AnyAsync(x => x.Id == r.CompanyId, ct)) throw new KeyNotFoundException("Company not found.");
        if (!await db.Categories.AnyAsync(x => x.Id == r.CategoryId && x.CompanyId == r.CompanyId, ct)) throw new KeyNotFoundException("Category not found.");
        if (r.BrandId.HasValue && !await db.Brands.AnyAsync(x => x.Id == r.BrandId && x.CompanyId == r.CompanyId, ct)) throw new KeyNotFoundException("Brand not found.");
        if (await db.Products.AnyAsync(x => x.CompanyId == r.CompanyId && x.Sku == sku, ct)) throw new InvalidOperationException("Product SKU already exists.");
        var p = new Product { CompanyId = r.CompanyId, CategoryId = r.CategoryId, BrandId = r.BrandId, Sku = sku, Name = name, Description = r.Description?.Trim(), Gender = r.Gender?.Trim(), Season = r.Season?.Trim(), Material = r.Material?.Trim() };
        foreach (var v in r.Variants)
        {
            var variantSku = Required(v.VariantSku, nameof(v.VariantSku), 80).ToUpperInvariant();
            if (v.CostPrice < 0 || v.SellingPrice < 0) throw new ArgumentException("Prices cannot be negative.");
            if (p.Variants.Any(x => x.VariantSku == variantSku)) throw new ArgumentException($"Duplicate variant SKU: {variantSku}");
            var barcode = string.IsNullOrWhiteSpace(v.Barcode) ? GenerateBarcode() : v.Barcode.Trim();
            if (await db.ProductVariants.AnyAsync(x => x.VariantSku == variantSku || x.Barcode == barcode, ct)) throw new InvalidOperationException($"Variant SKU or barcode already exists: {variantSku}");
            p.Variants.Add(new ProductVariant { VariantSku = variantSku, Barcode = barcode, Color = Required(v.Color, nameof(v.Color), 50), Size = Required(v.Size, nameof(v.Size), 30), CostPrice = v.CostPrice, SellingPrice = v.SellingPrice, ImageUrl = v.ImageUrl?.Trim() });
        }
        db.Products.Add(p); await db.SaveChangesAsync(ct); return MapProduct(p);
    }

    public async Task<IReadOnlyCollection<InventoryResponse>> GetInventoryAsync(Guid storeId, string? search, bool lowStockOnly, CancellationToken ct)
    {
        var q = db.Inventories.AsNoTracking().Include(x => x.ProductVariant).ThenInclude(x => x.Product).Where(x => x.StoreId == storeId);
        if (lowStockOnly) q = q.Where(x => x.QuantityOnHand - x.ReservedQuantity <= x.ReorderPoint);
        if (!string.IsNullOrWhiteSpace(search)) { var s = search.Trim().ToLower(); q = q.Where(x => x.ProductVariant.Barcode == search || x.ProductVariant.VariantSku.ToLower().Contains(s) || x.ProductVariant.Product.Name.ToLower().Contains(s)); }
        var items = await q.OrderBy(x => x.ProductVariant.Product.Name).ToListAsync(ct);
        return items.Select(MapInventory).ToList();
    }

    public async Task<InventoryResponse> AdjustInventoryAsync(AdjustInventoryRequest r, CancellationToken ct)
    {
        if (r.QuantityChange == 0) throw new ArgumentException("Quantity change cannot be zero.");
        if (!await db.Stores.AnyAsync(x => x.Id == r.StoreId, ct)) throw new KeyNotFoundException("Store not found.");
        if (!await db.ProductVariants.AnyAsync(x => x.Id == r.ProductVariantId, ct)) throw new KeyNotFoundException("Product variant not found.");
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var inv = await db.Inventories.Include(x => x.ProductVariant).ThenInclude(x => x.Product).SingleOrDefaultAsync(x => x.StoreId == r.StoreId && x.ProductVariantId == r.ProductVariantId, ct);
        if (inv is null) { inv = new Inventory { StoreId = r.StoreId, ProductVariantId = r.ProductVariantId }; db.Inventories.Add(inv); await db.SaveChangesAsync(ct); inv = await db.Inventories.Include(x => x.ProductVariant).ThenInclude(x => x.Product).SingleAsync(x => x.Id == inv.Id, ct); }
        var next = inv.QuantityOnHand + r.QuantityChange; if (next < 0) throw new InvalidOperationException("Insufficient stock. Negative inventory is not allowed.");
        inv.QuantityOnHand = next;
        db.InventoryTransactions.Add(new InventoryTransaction { StoreId = r.StoreId, ProductVariantId = r.ProductVariantId, Type = r.Type, QuantityChange = r.QuantityChange, QuantityAfter = next, ReferenceNumber = r.ReferenceNumber?.Trim(), Remarks = r.Remarks?.Trim(), CreatedByUserId = r.UserId });
        await db.SaveChangesAsync(ct); await tx.CommitAsync(ct); return MapInventory(inv);
    }

    public async Task TransferInventoryAsync(TransferInventoryRequest r, CancellationToken ct)
    {
        if (r.FromStoreId == r.ToStoreId) throw new ArgumentException("Source and destination stores must be different.");
        if (r.Quantity <= 0) throw new ArgumentException("Transfer quantity must be greater than zero.");
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var source = await db.Inventories.SingleOrDefaultAsync(x => x.StoreId == r.FromStoreId && x.ProductVariantId == r.ProductVariantId, ct) ?? throw new InvalidOperationException("Source inventory does not exist.");
        if (source.AvailableQuantity < r.Quantity) throw new InvalidOperationException("Insufficient available stock for transfer.");
        var destination = await db.Inventories.SingleOrDefaultAsync(x => x.StoreId == r.ToStoreId && x.ProductVariantId == r.ProductVariantId, ct);
        if (destination is null) { destination = new Inventory { StoreId = r.ToStoreId, ProductVariantId = r.ProductVariantId }; db.Inventories.Add(destination); }
        source.QuantityOnHand -= r.Quantity; destination.QuantityOnHand += r.Quantity;
        var reference = string.IsNullOrWhiteSpace(r.ReferenceNumber) ? $"TRF-{DateTime.UtcNow:yyyyMMddHHmmss}" : r.ReferenceNumber.Trim();
        db.InventoryTransactions.AddRange(
            new InventoryTransaction { StoreId = r.FromStoreId, ProductVariantId = r.ProductVariantId, Type = InventoryTransactionType.TransferOut, QuantityChange = -r.Quantity, QuantityAfter = source.QuantityOnHand, ReferenceNumber = reference, Remarks = r.Remarks?.Trim(), CreatedByUserId = r.UserId },
            new InventoryTransaction { StoreId = r.ToStoreId, ProductVariantId = r.ProductVariantId, Type = InventoryTransactionType.TransferIn, QuantityChange = r.Quantity, QuantityAfter = destination.QuantityOnHand, ReferenceNumber = reference, Remarks = r.Remarks?.Trim(), CreatedByUserId = r.UserId });
        await db.SaveChangesAsync(ct); await tx.CommitAsync(ct);
    }

    public async Task<IReadOnlyCollection<InventoryTransactionResponse>> GetInventoryHistoryAsync(Guid storeId, Guid? variantId, CancellationToken ct)
    {
        var q = db.InventoryTransactions.AsNoTracking().Where(x => x.StoreId == storeId); if (variantId.HasValue) q = q.Where(x => x.ProductVariantId == variantId);
        return await q.OrderByDescending(x => x.CreatedAtUtc).Take(500).Select(x => new InventoryTransactionResponse(x.Id, x.StoreId, x.ProductVariantId, x.Type, x.QuantityChange, x.QuantityAfter, x.ReferenceNumber, x.Remarks, x.CreatedAtUtc)).ToListAsync(ct);
    }

    private static ProductResponse MapProduct(Product p) => new(p.Id, p.CompanyId, p.CategoryId, p.BrandId, p.Sku, p.Name, p.Description, p.IsActive, p.Variants.OrderBy(v => v.Color).ThenBy(v => v.Size).Select(v => new VariantResponse(v.Id, v.VariantSku, v.Barcode, v.Color, v.Size, v.CostPrice, v.SellingPrice, v.IsActive)).ToList());
    private static InventoryResponse MapInventory(Inventory x) => new(x.Id, x.StoreId, x.ProductVariantId, x.ProductVariant.Product.Name, x.ProductVariant.VariantSku, x.ProductVariant.Barcode, x.ProductVariant.Color, x.ProductVariant.Size, x.QuantityOnHand, x.ReservedQuantity, x.AvailableQuantity, x.MinimumStock, x.ReorderPoint);
    private static string Required(string? value, string field, int max) { var x = value?.Trim(); if (string.IsNullOrWhiteSpace(x)) throw new ArgumentException($"{field} is required."); if (x.Length > max) throw new ArgumentException($"{field} cannot exceed {max} characters."); return x; }
    private static string Slugify(string value) => string.Join('-', value.ToLowerInvariant().Split(' ', StringSplitOptions.RemoveEmptyEntries)).Replace("/", "-");
    private static string GenerateBarcode() => $"480{DateTime.UtcNow:yyMMddHHmmss}{Random.Shared.Next(10, 99)}";
}
