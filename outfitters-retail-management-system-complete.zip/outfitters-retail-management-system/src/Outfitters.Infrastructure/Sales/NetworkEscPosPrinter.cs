using System.Net.Sockets;
using Outfitters.Application.Sales;
namespace Outfitters.Infrastructure.Sales;
public sealed class NetworkEscPosPrinter : IReceiptPrinter
{
    public async Task PrintAsync(byte[] document, string host, int port, int copies, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(host)) throw new ArgumentException("Printer host is required.");
        if (copies is < 1 or > 10) throw new ArgumentOutOfRangeException(nameof(copies));
        for (var i = 0; i < copies; i++)
        {
            using var client = new TcpClient();
            await client.ConnectAsync(host, port, ct);
            await using var stream = client.GetStream();
            await stream.WriteAsync(document, ct);
            await stream.FlushAsync(ct);
        }
    }
}
