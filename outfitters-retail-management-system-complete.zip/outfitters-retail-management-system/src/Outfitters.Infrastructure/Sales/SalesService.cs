using System.Text;
using Microsoft.EntityFrameworkCore;
using Outfitters.Application.Sales;
using Outfitters.Domain.Entities;
using Outfitters.Domain.Enums;
using Outfitters.Infrastructure.Persistence;
namespace Outfitters.Infrastructure.Sales;
public sealed class SalesService(ApplicationDbContext db) : ISalesService
{
    public async Task<SaleResponse> CheckoutAsync(CheckoutRequest r, CancellationToken ct)
    {
        if (r.Items is null || r.Items.Count == 0) throw new ArgumentException("At least one sale item is required.");
        if (r.Payments is null || r.Payments.Count == 0) throw new ArgumentException("At least one payment is required.");
        if (!await db.Stores.AnyAsync(x => x.Id == r.StoreId, ct)) throw new KeyNotFoundException("Store not found.");
        if (!await db.Users.AnyAsync(x => x.Id == r.CashierId && x.StoreId == r.StoreId && x.IsActive, ct)) throw new KeyNotFoundException("Active cashier not found for this store.");
        if (r.Items.Any(x => x.Quantity <= 0 || x.DiscountAmount < 0)) throw new ArgumentException("Item quantity must be positive and discounts cannot be negative.");
        if (r.Payments.Any(x => x.Amount <= 0)) throw new ArgumentException("Payment amounts must be positive.");
        await using var tx = await db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable, ct);
        var ids = r.Items.Select(x => x.ProductVariantId).Distinct().ToArray();
        if (ids.Length != r.Items.Count) throw new ArgumentException("Duplicate product variants must be combined into one line.");
        var inventories = await db.Inventories.Include(x => x.ProductVariant).ThenInclude(x => x.Product)
            .Where(x => x.StoreId == r.StoreId && ids.Contains(x.ProductVariantId)).ToDictionaryAsync(x => x.ProductVariantId, ct);
        if (inventories.Count != ids.Length) throw new InvalidOperationException("One or more items do not have inventory in this store.");
        if (r.CustomerId.HasValue && !await db.Customers.AnyAsync(x => x.Id == r.CustomerId.Value && x.IsActive, ct)) throw new KeyNotFoundException("Active customer not found.");
        var sale = new Sale { StoreId = r.StoreId, CashierId = r.CashierId, CustomerId = r.CustomerId, ReceiptNumber = await NextReceiptAsync(r.StoreId, ct), TaxTotal = r.TaxTotal, Notes = r.Notes?.Trim() };
        decimal subtotal = 0, discounts = 0;
        foreach (var line in r.Items)
        {
            var inv = inventories[line.ProductVariantId];
            if (inv.AvailableQuantity < line.Quantity) throw new InvalidOperationException($"Insufficient stock for {inv.ProductVariant.VariantSku}.");
            var gross = inv.ProductVariant.SellingPrice * line.Quantity;
            if (line.DiscountAmount > gross) throw new ArgumentException($"Discount exceeds line value for {inv.ProductVariant.VariantSku}.");
            subtotal += gross; discounts += line.DiscountAmount;
            var itemTax = r.TaxTotal == 0 ? 0 : decimal.Round(r.TaxTotal * (gross - line.DiscountAmount) / Math.Max(0.01m, r.Items.Sum(i => inventories[i.ProductVariantId].ProductVariant.SellingPrice * i.Quantity - i.DiscountAmount)), 2);
            sale.Items.Add(new SaleItem { ProductVariantId = line.ProductVariantId, ProductNameSnapshot = inv.ProductVariant.Product.Name, VariantSnapshot = $"{inv.ProductVariant.Color} / {inv.ProductVariant.Size}", BarcodeSnapshot = inv.ProductVariant.Barcode, Quantity = line.Quantity, UnitPrice = inv.ProductVariant.SellingPrice, DiscountAmount = line.DiscountAmount, TaxAmount = itemTax, LineTotal = gross - line.DiscountAmount + itemTax });
            inv.QuantityOnHand -= line.Quantity;
            db.InventoryTransactions.Add(new InventoryTransaction { StoreId = r.StoreId, ProductVariantId = line.ProductVariantId, Type = InventoryTransactionType.Sale, QuantityChange = -line.Quantity, QuantityAfter = inv.QuantityOnHand, ReferenceNumber = sale.ReceiptNumber, Remarks = "POS sale", CreatedByUserId = r.CashierId });
        }
        sale.Subtotal = subtotal; sale.DiscountTotal = discounts; sale.GrandTotal = subtotal - discounts + r.TaxTotal;
        var paid = r.Payments.Sum(x => x.Amount); if (paid < sale.GrandTotal) throw new InvalidOperationException("Payment is less than the grand total.");
        sale.ChangeDue = paid - sale.GrandTotal;
        foreach (var payment in r.Payments) sale.Payments.Add(new Payment { Method = payment.Method, Amount = payment.Amount, ReferenceNumber = payment.ReferenceNumber?.Trim() });
        db.Sales.Add(sale);
        if (r.CustomerId.HasValue)
        {
            var customer = await db.Customers.SingleAsync(x => x.Id == r.CustomerId.Value, ct);
            var earned = decimal.Floor(sale.GrandTotal / 100m);
            if (earned > 0)
            {
                customer.LoyaltyPointsBalance += earned;
                db.LoyaltyTransactions.Add(new LoyaltyTransaction { CustomerId = customer.Id, Type = LoyaltyTransactionType.Earned, Points = earned, BalanceAfter = customer.LoyaltyPointsBalance, ReferenceNumber = sale.ReceiptNumber, Notes = "Points earned from POS sale", CreatedByUserId = r.CashierId });
            }
        }
        await db.SaveChangesAsync(ct); await tx.CommitAsync(ct);
        return Map(sale);
    }

    public async Task<SaleResponse?> GetSaleAsync(Guid id, CancellationToken ct)
    {
        var sale = await Query().SingleOrDefaultAsync(x => x.Id == id, ct); return sale is null ? null : Map(sale);
    }
    public async Task<IReadOnlyCollection<SaleResponse>> GetSalesAsync(Guid storeId, DateTime? fromUtc, DateTime? toUtc, CancellationToken ct)
    {
        var q = Query().Where(x => x.StoreId == storeId); if (fromUtc.HasValue) q = q.Where(x => x.CreatedAtUtc >= fromUtc); if (toUtc.HasValue) q = q.Where(x => x.CreatedAtUtc < toUtc);
        return (await q.OrderByDescending(x => x.CreatedAtUtc).Take(500).ToListAsync(ct)).Select(Map).ToList();
    }
    public async Task<byte[]> BuildReceiptAsync(Guid saleId, CancellationToken ct)
    {
        var s = await db.Sales.AsNoTracking().Include(x => x.Store).Include(x => x.Cashier).Include(x => x.Items).Include(x => x.Payments).SingleOrDefaultAsync(x => x.Id == saleId, ct) ?? throw new KeyNotFoundException("Sale not found.");
        var b = new List<byte>(); void Add(params byte[] x) => b.AddRange(x); void Text(string x) => Add(Encoding.ASCII.GetBytes(x.Replace('₱','P')));
        Add(0x1B,0x40); Add(0x1B,0x61,0x01); Add(0x1B,0x45,0x01); Text("OUTFITTERS APPAREL STORE
"); Add(0x1B,0x45,0x00); Text($"{s.Store.Name}
"); Text($"Receipt: {s.ReceiptNumber}
{s.CreatedAtUtc:yyyy-MM-dd HH:mm} UTC
"); Add(0x1B,0x61,0x00); Text(new string('-',32)+"
");
        foreach (var i in s.Items) { Text($"{Trim(i.ProductNameSnapshot,22)}
"); Text($" {i.Quantity} x {i.UnitPrice,8:0.00} {i.LineTotal,10:0.00}
"); }
        Text(new string('-',32)+"
"); Text($"Subtotal:{s.Subtotal,22:0.00}
Discount:{s.DiscountTotal,22:0.00}
Tax:{s.TaxTotal,27:0.00}
"); Add(0x1B,0x45,0x01); Text($"TOTAL:{s.GrandTotal,25:0.00}
"); Add(0x1B,0x45,0x00);
        foreach (var x in s.Payments) Text($"{x.Method}:{x.Amount,25:0.00}
"); Text($"Change:{s.ChangeDue,24:0.00}
"); Add(0x1B,0x61,0x01); Text("
Thank you for shopping!


"); Add(0x1D,0x56,0x00); return b.ToArray();
    }
    private IQueryable<Sale> Query() => db.Sales.AsNoTracking().Include(x => x.Items).Include(x => x.Payments);
    private async Task<string> NextReceiptAsync(Guid storeId, CancellationToken ct) { var prefix = DateTime.UtcNow.ToString("yyyyMMdd"); var count = await db.Sales.IgnoreQueryFilters().CountAsync(x => x.StoreId == storeId && x.CreatedAtUtc.Date == DateTime.UtcNow.Date, ct) + 1; return $"{prefix}-{count:00000}"; }
    private static string Trim(string x,int n) => x.Length <= n ? x : x[..n];
    private static SaleResponse Map(Sale x) => new(x.Id,x.ReceiptNumber,x.StoreId,x.CashierId,x.CreatedAtUtc,x.Subtotal,x.DiscountTotal,x.TaxTotal,x.GrandTotal,x.ChangeDue,x.Status,x.Items.Select(i=>new SaleItemResponse(i.ProductVariantId,i.ProductNameSnapshot,i.VariantSnapshot,i.BarcodeSnapshot,i.Quantity,i.UnitPrice,i.DiscountAmount,i.TaxAmount,i.LineTotal)).ToList(),x.Payments.Select(v=>new PaymentResponse(v.Method,v.Amount,v.ReferenceNumber)).ToList());
}
