using Microsoft.EntityFrameworkCore;
using Outfitters.Domain.Common;
using Outfitters.Domain.Entities;
namespace Outfitters.Infrastructure.Persistence;
public sealed class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : DbContext(options)
{
    public DbSet<Company> Companies => Set<Company>();
    public DbSet<Store> Stores => Set<Store>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<User> Users => Set<User>();
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Brand> Brands => Set<Brand>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<ProductVariant> ProductVariants => Set<ProductVariant>();
    public DbSet<Inventory> Inventories => Set<Inventory>();
    public DbSet<InventoryTransaction> InventoryTransactions => Set<InventoryTransaction>();
    public DbSet<Sale> Sales => Set<Sale>();
    public DbSet<SaleItem> SaleItems => Set<SaleItem>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<Supplier> Suppliers => Set<Supplier>();
    public DbSet<PurchaseOrder> PurchaseOrders => Set<PurchaseOrder>();
    public DbSet<PurchaseOrderItem> PurchaseOrderItems => Set<PurchaseOrderItem>();
    public DbSet<GoodsReceipt> GoodsReceipts => Set<GoodsReceipt>();
    public DbSet<GoodsReceiptItem> GoodsReceiptItems => Set<GoodsReceiptItem>();
    public DbSet<StockTransfer> StockTransfers => Set<StockTransfer>();
    public DbSet<StockTransferItem> StockTransferItems => Set<StockTransferItem>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<LoyaltyTransaction> LoyaltyTransactions => Set<LoyaltyTransaction>();
    public DbSet<SaleReturn> SaleReturns => Set<SaleReturn>();
    public DbSet<SaleReturnItem> SaleReturnItems => Set<SaleReturnItem>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Company>().HasIndex(x => x.Code).IsUnique();
        b.Entity<Store>().HasIndex(x => new { x.CompanyId, x.Code }).IsUnique();
        b.Entity<Role>().HasIndex(x => x.Name).IsUnique();
        b.Entity<Permission>().HasIndex(x => x.Code).IsUnique();
        b.Entity<User>().HasIndex(x => x.Username).IsUnique();
        b.Entity<RolePermission>().HasKey(x => new { x.RoleId, x.PermissionId });
        b.Entity<RefreshToken>().HasIndex(x => x.TokenHash).IsUnique();
        b.Entity<Category>().HasIndex(x => new { x.CompanyId, x.Slug }).IsUnique();
        b.Entity<Brand>().HasIndex(x => new { x.CompanyId, x.Name }).IsUnique();
        b.Entity<Product>().HasIndex(x => new { x.CompanyId, x.Sku }).IsUnique();
        b.Entity<ProductVariant>().HasIndex(x => x.VariantSku).IsUnique();
        b.Entity<ProductVariant>().HasIndex(x => x.Barcode).IsUnique();
        b.Entity<Inventory>().HasIndex(x => new { x.StoreId, x.ProductVariantId }).IsUnique();
        b.Entity<Sale>().HasIndex(x => new { x.StoreId, x.ReceiptNumber }).IsUnique();
        b.Entity<Supplier>().HasIndex(x => new { x.CompanyId, x.Code }).IsUnique();
        b.Entity<PurchaseOrder>().HasIndex(x => new { x.StoreId, x.Number }).IsUnique();
        b.Entity<GoodsReceipt>().HasIndex(x => x.Number).IsUnique();
        b.Entity<StockTransfer>().HasIndex(x => x.Number).IsUnique();
        b.Entity<Customer>().HasIndex(x => new { x.CompanyId, x.CustomerNumber }).IsUnique();
        b.Entity<Customer>().HasIndex(x => new { x.CompanyId, x.Email });
        b.Entity<SaleReturn>().HasIndex(x => new { x.StoreId, x.ReturnNumber }).IsUnique();
        b.Entity<Sale>().Property(x => x.Subtotal).HasPrecision(18, 2);
        b.Entity<Sale>().Property(x => x.DiscountTotal).HasPrecision(18, 2);
        b.Entity<Sale>().Property(x => x.TaxTotal).HasPrecision(18, 2);
        b.Entity<Sale>().Property(x => x.GrandTotal).HasPrecision(18, 2);
        b.Entity<Sale>().Property(x => x.ChangeDue).HasPrecision(18, 2);
        b.Entity<SaleItem>().Property(x => x.UnitPrice).HasPrecision(18, 2);
        b.Entity<SaleItem>().Property(x => x.DiscountAmount).HasPrecision(18, 2);
        b.Entity<SaleItem>().Property(x => x.TaxAmount).HasPrecision(18, 2);
        b.Entity<SaleItem>().Property(x => x.LineTotal).HasPrecision(18, 2);
        b.Entity<Payment>().Property(x => x.Amount).HasPrecision(18, 2);
        b.Entity<PurchaseOrder>().Property(x => x.Subtotal).HasPrecision(18, 2);
        b.Entity<PurchaseOrder>().Property(x => x.TaxTotal).HasPrecision(18, 2);
        b.Entity<PurchaseOrder>().Property(x => x.DiscountTotal).HasPrecision(18, 2);
        b.Entity<PurchaseOrder>().Property(x => x.GrandTotal).HasPrecision(18, 2);
        b.Entity<PurchaseOrderItem>().Property(x => x.UnitCost).HasPrecision(18, 2);
        b.Entity<PurchaseOrderItem>().Property(x => x.LineTotal).HasPrecision(18, 2);
        b.Entity<GoodsReceiptItem>().Property(x => x.UnitCost).HasPrecision(18, 2);
        b.Entity<ProductVariant>().Property(x => x.CostPrice).HasPrecision(18, 2);
        b.Entity<Customer>().Property(x => x.LoyaltyPointsBalance).HasPrecision(18, 2);
        b.Entity<LoyaltyTransaction>().Property(x => x.Points).HasPrecision(18, 2);
        b.Entity<LoyaltyTransaction>().Property(x => x.BalanceAfter).HasPrecision(18, 2);
        b.Entity<SaleReturn>().Property(x => x.RefundTotal).HasPrecision(18, 2);
        b.Entity<SaleReturnItem>().Property(x => x.UnitRefund).HasPrecision(18, 2);
        b.Entity<SaleReturnItem>().Property(x => x.LineRefund).HasPrecision(18, 2);
        b.Entity<ProductVariant>().Property(x => x.SellingPrice).HasPrecision(18, 2);
        b.Entity<Category>().HasOne(x => x.ParentCategory).WithMany(x => x.Children).HasForeignKey(x => x.ParentCategoryId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Product>().HasOne(x => x.Brand).WithMany(x => x.Products).HasForeignKey(x => x.BrandId).OnDelete(DeleteBehavior.SetNull);
        b.Entity<InventoryTransaction>().HasOne(x => x.CreatedByUser).WithMany().HasForeignKey(x => x.CreatedByUserId).OnDelete(DeleteBehavior.SetNull);
        b.Entity<StockTransfer>().HasOne(x => x.SourceStore).WithMany().HasForeignKey(x => x.SourceStoreId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<StockTransfer>().HasOne(x => x.DestinationStore).WithMany().HasForeignKey(x => x.DestinationStoreId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<StockTransfer>().HasOne(x => x.CreatedByUser).WithMany().HasForeignKey(x => x.CreatedByUserId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<PurchaseOrder>().HasOne(x => x.CreatedByUser).WithMany().HasForeignKey(x => x.CreatedByUserId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Sale>().HasOne(x => x.Customer).WithMany().HasForeignKey(x => x.CustomerId).OnDelete(DeleteBehavior.SetNull);
        b.Entity<LoyaltyTransaction>().HasOne(x => x.CreatedByUser).WithMany().HasForeignKey(x => x.CreatedByUserId).OnDelete(DeleteBehavior.SetNull);
        b.Entity<SaleReturn>().HasOne(x => x.ProcessedByUser).WithMany().HasForeignKey(x => x.ProcessedByUserId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<SaleReturnItem>().HasOne(x => x.SaleItem).WithMany().HasForeignKey(x => x.SaleItemId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<GoodsReceipt>().HasOne(x => x.ReceivedByUser).WithMany().HasForeignKey(x => x.ReceivedByUserId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<User>().Property(x => x.Username).HasMaxLength(80);
        b.Entity<Company>().Property(x => x.Code).HasMaxLength(20);
        b.Entity<Store>().Property(x => x.Code).HasMaxLength(20);
        foreach (var entityType in b.Model.GetEntityTypes())
            if (typeof(BaseEntity).IsAssignableFrom(entityType.ClrType))
                b.Entity(entityType.ClrType).HasQueryFilter(CreateSoftDeleteFilter(entityType.ClrType));
    }

    private static System.Linq.Expressions.LambdaExpression CreateSoftDeleteFilter(Type type)
    {
        var p = System.Linq.Expressions.Expression.Parameter(type, "e");
        var prop = System.Linq.Expressions.Expression.Property(p, nameof(BaseEntity.IsDeleted));
        return System.Linq.Expressions.Expression.Lambda(System.Linq.Expressions.Expression.Equal(prop, System.Linq.Expressions.Expression.Constant(false)), p);
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        foreach (var entry in ChangeTracker.Entries<BaseEntity>())
        {
            if (entry.State == EntityState.Added) entry.Entity.CreatedAtUtc = DateTime.UtcNow;
            if (entry.State == EntityState.Modified) entry.Entity.UpdatedAtUtc = DateTime.UtcNow;
        }
        return await base.SaveChangesAsync(cancellationToken);
    }
}
