using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Outfitters.Domain.Entities;
namespace Outfitters.Infrastructure.Persistence;
public static class DatabaseSeeder
{
    public static async Task SeedAsync(ApplicationDbContext db, IPasswordHasher<User> hasher, CancellationToken ct = default)
    {
        await db.Database.EnsureCreatedAsync(ct);
        if (await db.Companies.AnyAsync(ct)) return;
        var company = new Company { Code = "OUT", Name = "Outfitters Apparel Store" };
        var store = new Store { Company = company, Code = "MAIN", Name = "Main Store", IsMainStore = true };
        var adminRole = new Role { Name = "Super Administrator", Description = "Full system access", IsSystemRole = true };
        var admin = new User { Store = store, Role = adminRole, Username = "admin", FirstName = "System", LastName = "Administrator", MustChangePassword = true };
        admin.PasswordHash = hasher.HashPassword(admin, "Admin@123");
        db.AddRange(company, store, adminRole, admin);
        await db.SaveChangesAsync(ct);
    }
}
