using Microsoft.EntityFrameworkCore;
using Outfitters.Application.Returns;
using Outfitters.Domain.Entities;
using Outfitters.Domain.Enums;
using Outfitters.Infrastructure.Persistence;
namespace Outfitters.Infrastructure.Returns;
public sealed class ReturnService(ApplicationDbContext db) : IReturnService
{
    public async Task<SaleReturnResponse> CreateAsync(CreateReturnRequest r, CancellationToken ct)
    {
        if (r.Items is null || r.Items.Count == 0) throw new ArgumentException("At least one return item is required.");
        if (string.IsNullOrWhiteSpace(r.Reason)) throw new ArgumentException("A return reason is required.");
        await using var tx = await db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable, ct);
        var sale = await db.Sales.Include(x => x.Items).SingleOrDefaultAsync(x => x.Id == r.SaleId, ct) ?? throw new KeyNotFoundException("Sale not found.");
        if (!await db.Users.AnyAsync(x => x.Id == r.ProcessedByUserId && x.StoreId == sale.StoreId && x.IsActive, ct)) throw new KeyNotFoundException("Active processing user not found for this store.");
        var returnIds = r.Items.Select(x => x.SaleItemId).Distinct().ToArray();
        if (returnIds.Length != r.Items.Count) throw new ArgumentException("Duplicate sale items must be combined.");
        var previous = await db.SaleReturnItems.Where(x => returnIds.Contains(x.SaleItemId) && x.SaleReturn.Status == SaleReturnStatus.Completed).GroupBy(x => x.SaleItemId).Select(g => new { Id = g.Key, Qty = g.Sum(x => x.Quantity) }).ToDictionaryAsync(x => x.Id, x => x.Qty, ct);
        var result = new SaleReturn { SaleId = sale.Id, StoreId = sale.StoreId, ProcessedByUserId = r.ProcessedByUserId, ReturnNumber = await NextNumberAsync(sale.StoreId, ct), Reason = r.Reason.Trim() };
        foreach (var request in r.Items)
        {
            var item = sale.Items.SingleOrDefault(x => x.Id == request.SaleItemId) ?? throw new KeyNotFoundException("Sale item not found in the selected sale.");
            var already = previous.GetValueOrDefault(item.Id);
            if (request.Quantity <= 0 || already + request.Quantity > item.Quantity) throw new InvalidOperationException($"Return quantity exceeds remaining quantity for {item.ProductNameSnapshot}.");
            var unitRefund = decimal.Round(item.LineTotal / item.Quantity, 2);
            var lineRefund = unitRefund * request.Quantity;
            result.Items.Add(new SaleReturnItem { SaleItemId = item.Id, ProductVariantId = item.ProductVariantId, Quantity = request.Quantity, UnitRefund = unitRefund, LineRefund = lineRefund, Restock = request.Restock });
            result.RefundTotal += lineRefund;
            if (request.Restock)
            {
                var inv = await db.Inventories.SingleOrDefaultAsync(x => x.StoreId == sale.StoreId && x.ProductVariantId == item.ProductVariantId, ct) ?? throw new InvalidOperationException("Inventory record not found for returned item.");
                inv.QuantityOnHand += request.Quantity;
                db.InventoryTransactions.Add(new InventoryTransaction { StoreId = sale.StoreId, ProductVariantId = item.ProductVariantId, Type = InventoryTransactionType.Return, QuantityChange = request.Quantity, QuantityAfter = inv.QuantityOnHand, ReferenceNumber = result.ReturnNumber, Remarks = r.Reason.Trim(), CreatedByUserId = r.ProcessedByUserId });
            }
        }
        db.SaleReturns.Add(result); await db.SaveChangesAsync(ct); await tx.CommitAsync(ct); return Map(result);
    }
    public async Task<SaleReturnResponse?> GetAsync(Guid id, CancellationToken ct) { var x = await Query().SingleOrDefaultAsync(v => v.Id == id, ct); return x is null ? null : Map(x); }
    public async Task<IReadOnlyCollection<SaleReturnResponse>> GetByStoreAsync(Guid storeId, DateTime? fromUtc, DateTime? toUtc, CancellationToken ct)
    {
        var q = Query().Where(x => x.StoreId == storeId); if (fromUtc.HasValue) q = q.Where(x => x.CreatedAtUtc >= fromUtc); if (toUtc.HasValue) q = q.Where(x => x.CreatedAtUtc < toUtc);
        return (await q.OrderByDescending(x => x.CreatedAtUtc).Take(500).ToListAsync(ct)).Select(Map).ToList();
    }
    private IQueryable<SaleReturn> Query() => db.SaleReturns.AsNoTracking().Include(x => x.Items);
    private async Task<string> NextNumberAsync(Guid storeId, CancellationToken ct) { var p = DateTime.UtcNow.ToString("yyyyMMdd"); var n = await db.SaleReturns.IgnoreQueryFilters().CountAsync(x => x.StoreId == storeId && x.CreatedAtUtc.Date == DateTime.UtcNow.Date, ct) + 1; return $"RET-{p}-{n:0000}"; }
    private static SaleReturnResponse Map(SaleReturn x) => new(x.Id,x.ReturnNumber,x.SaleId,x.StoreId,x.RefundTotal,x.Reason,x.Status,x.CreatedAtUtc,x.Items.Select(i=>new ReturnItemResponse(i.SaleItemId,i.ProductVariantId,i.Quantity,i.UnitRefund,i.LineRefund,i.Restock)).ToList());
}
