namespace Outfitters.Application.Reporting;
public interface IReportingService
{
    Task<DashboardSummaryResponse> GetDashboardAsync(Guid storeId, CancellationToken ct);
    Task<IReadOnlyCollection<MonthlySalesPoint>> GetMonthlySalesAsync(Guid storeId, int year, CancellationToken ct);
    Task<IReadOnlyCollection<TopProductResponse>> GetTopProductsAsync(Guid storeId, DateTime fromUtc, DateTime toUtc, int take, CancellationToken ct);
    Task<IReadOnlyCollection<PaymentSummaryResponse>> GetPaymentSummaryAsync(Guid storeId, DateTime fromUtc, DateTime toUtc, CancellationToken ct);
}
