namespace Outfitters.Application.Reporting;
public sealed record DashboardSummaryResponse(decimal TodaySales, decimal MonthSales, int TodayTransactions, int LowStockItems, decimal InventoryValue, decimal MonthRefunds);
public sealed record MonthlySalesPoint(int Year, int Month, string MonthName, decimal GrossSales, decimal Discounts, decimal Tax, decimal NetSales, decimal Refunds, int Transactions, int UnitsSold);
public sealed record TopProductResponse(Guid ProductVariantId, string ProductName, string Variant, int QuantitySold, decimal NetSales);
public sealed record PaymentSummaryResponse(string Method, decimal Amount, int Transactions);
