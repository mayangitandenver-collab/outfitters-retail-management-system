namespace Outfitters.Application.Sales;
public interface IReceiptPrinter
{
    Task PrintAsync(byte[] document, string host, int port, int copies, CancellationToken ct);
}
