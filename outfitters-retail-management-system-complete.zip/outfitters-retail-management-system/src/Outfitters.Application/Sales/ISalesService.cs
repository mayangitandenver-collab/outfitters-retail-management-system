namespace Outfitters.Application.Sales;
public interface ISalesService
{
    Task<SaleResponse> CheckoutAsync(CheckoutRequest request, CancellationToken ct);
    Task<SaleResponse?> GetSaleAsync(Guid id, CancellationToken ct);
    Task<IReadOnlyCollection<SaleResponse>> GetSalesAsync(Guid storeId, DateTime? fromUtc, DateTime? toUtc, CancellationToken ct);
    Task<byte[]> BuildReceiptAsync(Guid saleId, CancellationToken ct);
}
