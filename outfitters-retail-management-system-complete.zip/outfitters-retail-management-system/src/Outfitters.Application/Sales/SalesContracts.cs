using Outfitters.Domain.Enums;
namespace Outfitters.Application.Sales;
public sealed record CheckoutItemRequest(Guid ProductVariantId, int Quantity, decimal DiscountAmount = 0);
public sealed record PaymentRequest(PaymentMethod Method, decimal Amount, string? ReferenceNumber = null);
public sealed record CheckoutRequest(Guid StoreId, Guid CashierId, IReadOnlyCollection<CheckoutItemRequest> Items, IReadOnlyCollection<PaymentRequest> Payments, decimal TaxTotal = 0, string? Notes = null, Guid? CustomerId = null);
public sealed record SaleItemResponse(Guid ProductVariantId, string ProductName, string Variant, string Barcode, int Quantity, decimal UnitPrice, decimal DiscountAmount, decimal TaxAmount, decimal LineTotal);
public sealed record PaymentResponse(PaymentMethod Method, decimal Amount, string? ReferenceNumber);
public sealed record SaleResponse(Guid Id, string ReceiptNumber, Guid StoreId, Guid CashierId, DateTime CreatedAtUtc, decimal Subtotal, decimal DiscountTotal, decimal TaxTotal, decimal GrandTotal, decimal ChangeDue, SaleStatus Status, IReadOnlyCollection<SaleItemResponse> Items, IReadOnlyCollection<PaymentResponse> Payments);
public sealed record ReceiptPrintRequest(string? PrinterHost = null, int PrinterPort = 9100, int Copies = 1);
