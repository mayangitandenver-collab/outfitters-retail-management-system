using Outfitters.Domain.Entities;
namespace Outfitters.Application.Common;
public sealed record AccessTokenResult(string Token, DateTime ExpiresAtUtc);
public interface IJwtTokenService
{
    AccessTokenResult CreateAccessToken(User user);
    string CreateRefreshToken();
    string HashRefreshToken(string token);
}
