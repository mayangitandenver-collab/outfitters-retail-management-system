namespace Outfitters.Application.Customers;
public interface ICustomerService
{
    Task<IReadOnlyCollection<CustomerResponse>> SearchAsync(Guid companyId, string? search, CancellationToken ct);
    Task<CustomerResponse?> GetAsync(Guid id, CancellationToken ct);
    Task<CustomerResponse> CreateAsync(CreateCustomerRequest request, CancellationToken ct);
    Task<CustomerResponse> UpdateAsync(Guid id, UpdateCustomerRequest request, CancellationToken ct);
    Task<LoyaltyTransactionResponse> AdjustLoyaltyAsync(Guid customerId, AdjustLoyaltyRequest request, CancellationToken ct);
    Task<IReadOnlyCollection<LoyaltyTransactionResponse>> GetLoyaltyHistoryAsync(Guid customerId, CancellationToken ct);
}
