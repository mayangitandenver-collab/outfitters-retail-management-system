using Outfitters.Domain.Enums;
namespace Outfitters.Application.Customers;
public sealed record CreateCustomerRequest(Guid CompanyId, string FirstName, string LastName, string? Email = null, string? Phone = null, DateOnly? BirthDate = null);
public sealed record UpdateCustomerRequest(string FirstName, string LastName, string? Email, string? Phone, DateOnly? BirthDate, bool IsActive);
public sealed record CustomerResponse(Guid Id, string CustomerNumber, string FirstName, string LastName, string? Email, string? Phone, DateOnly? BirthDate, decimal LoyaltyPointsBalance, bool IsActive);
public sealed record AdjustLoyaltyRequest(decimal Points, string Notes, Guid? CreatedByUserId = null);
public sealed record LoyaltyTransactionResponse(Guid Id, LoyaltyTransactionType Type, decimal Points, decimal BalanceAfter, string? ReferenceNumber, string? Notes, DateTime CreatedAtUtc);
