namespace Outfitters.Application.Catalog;
public interface ICatalogService
{
    Task<IReadOnlyCollection<CategoryResponse>> GetCategoriesAsync(Guid companyId, CancellationToken ct);
    Task<CategoryResponse> CreateCategoryAsync(CreateCategoryRequest request, CancellationToken ct);
    Task<IReadOnlyCollection<BrandResponse>> GetBrandsAsync(Guid companyId, CancellationToken ct);
    Task<BrandResponse> CreateBrandAsync(CreateBrandRequest request, CancellationToken ct);
    Task<IReadOnlyCollection<ProductResponse>> GetProductsAsync(Guid companyId, string? search, CancellationToken ct);
    Task<ProductResponse?> GetProductAsync(Guid id, CancellationToken ct);
    Task<ProductResponse> CreateProductAsync(CreateProductRequest request, CancellationToken ct);
    Task<IReadOnlyCollection<InventoryResponse>> GetInventoryAsync(Guid storeId, string? search, bool lowStockOnly, CancellationToken ct);
    Task<InventoryResponse> AdjustInventoryAsync(AdjustInventoryRequest request, CancellationToken ct);
    Task TransferInventoryAsync(TransferInventoryRequest request, CancellationToken ct);
    Task<IReadOnlyCollection<InventoryTransactionResponse>> GetInventoryHistoryAsync(Guid storeId, Guid? variantId, CancellationToken ct);
}
