using Outfitters.Domain.Enums;
namespace Outfitters.Application.Returns;
public sealed record ReturnItemRequest(Guid SaleItemId, int Quantity, bool Restock = true);
public sealed record CreateReturnRequest(Guid SaleId, Guid ProcessedByUserId, string Reason, IReadOnlyCollection<ReturnItemRequest> Items);
public sealed record ReturnItemResponse(Guid SaleItemId, Guid ProductVariantId, int Quantity, decimal UnitRefund, decimal LineRefund, bool Restock);
public sealed record SaleReturnResponse(Guid Id, string ReturnNumber, Guid SaleId, Guid StoreId, decimal RefundTotal, string Reason, SaleReturnStatus Status, DateTime CreatedAtUtc, IReadOnlyCollection<ReturnItemResponse> Items);
