namespace Outfitters.Application.Returns;
public interface IReturnService
{
    Task<SaleReturnResponse> CreateAsync(CreateReturnRequest request, CancellationToken ct);
    Task<SaleReturnResponse?> GetAsync(Guid id, CancellationToken ct);
    Task<IReadOnlyCollection<SaleReturnResponse>> GetByStoreAsync(Guid storeId, DateTime? fromUtc, DateTime? toUtc, CancellationToken ct);
}
