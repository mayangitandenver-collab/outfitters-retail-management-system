namespace Outfitters.Application.Auth;
public sealed record LoginRequest(string Username, string Password);
public sealed record RefreshRequest(string RefreshToken);
public sealed record LogoutRequest(string RefreshToken);
public sealed record AuthResponse(string AccessToken, string RefreshToken, DateTime ExpiresAtUtc, UserSummary User);
public sealed record UserSummary(Guid Id, string Username, string FullName, string Role, Guid StoreId, bool MustChangePassword);
