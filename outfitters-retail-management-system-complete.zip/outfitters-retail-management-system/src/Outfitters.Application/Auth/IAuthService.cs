namespace Outfitters.Application.Auth;
public interface IAuthService
{
    Task<AuthResponse?> LoginAsync(LoginRequest request, string? ipAddress, CancellationToken cancellationToken);
    Task<AuthResponse?> RefreshAsync(RefreshRequest request, string? ipAddress, CancellationToken cancellationToken);
    Task<bool> LogoutAsync(LogoutRequest request, CancellationToken cancellationToken);
}
