namespace Outfitters.Application.Purchasing;
public interface IPurchasingService
{
    Task<IReadOnlyCollection<SupplierResponse>> GetSuppliersAsync(Guid companyId, CancellationToken ct);
    Task<SupplierResponse> CreateSupplierAsync(SupplierRequest request, CancellationToken ct);
    Task<PurchaseOrderResponse> CreatePurchaseOrderAsync(CreatePurchaseOrderRequest request, CancellationToken ct);
    Task<PurchaseOrderResponse?> GetPurchaseOrderAsync(Guid id, CancellationToken ct);
    Task<IReadOnlyCollection<PurchaseOrderResponse>> GetPurchaseOrdersAsync(Guid storeId, CancellationToken ct);
    Task<PurchaseOrderResponse> ApprovePurchaseOrderAsync(Guid id, CancellationToken ct);
    Task<GoodsReceiptResponse> ReceivePurchaseOrderAsync(Guid id, ReceivePurchaseOrderRequest request, CancellationToken ct);
    Task<StockTransferResponse> CreateStockTransferAsync(CreateStockTransferRequest request, CancellationToken ct);
    Task<StockTransferResponse> DispatchStockTransferAsync(Guid id, Guid userId, CancellationToken ct);
    Task<StockTransferResponse> ReceiveStockTransferAsync(Guid id, Guid userId, CancellationToken ct);
    Task<StockTransferResponse?> GetStockTransferAsync(Guid id, CancellationToken ct);
}
