using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace Outfitters.API.Controllers;
[ApiController, Route("api/system")]
public sealed class SystemController : ControllerBase
{
    [AllowAnonymous, HttpGet("info")]
    public IActionResult Info() => Ok(new { name = "Outfitters Retail Management System", apiVersion = "1.0.0", utc = DateTime.UtcNow });
    [Authorize, HttpGet("me")]
    public IActionResult Me() => Ok(new { username = User.Identity?.Name, claims = User.Claims.Select(x => new { x.Type, x.Value }) });
}
