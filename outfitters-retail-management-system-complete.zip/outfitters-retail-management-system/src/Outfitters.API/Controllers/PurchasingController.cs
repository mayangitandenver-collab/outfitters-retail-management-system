using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Outfitters.Application.Purchasing;
namespace Outfitters.API.Controllers;
[ApiController, Route("api/purchasing"), Authorize]
public sealed class PurchasingController(IPurchasingService service) : ControllerBase
{
    [HttpGet("suppliers")] public async Task<ActionResult<IReadOnlyCollection<SupplierResponse>>> Suppliers([FromQuery] Guid companyId, CancellationToken ct) => Ok(await service.GetSuppliersAsync(companyId, ct));
    [HttpPost("suppliers")] public async Task<ActionResult<SupplierResponse>> CreateSupplier(SupplierRequest request, CancellationToken ct) { var x = await service.CreateSupplierAsync(request, ct); return CreatedAtAction(nameof(Suppliers), new { companyId = x.CompanyId }, x); }
    [HttpPost("purchase-orders")] public async Task<ActionResult<PurchaseOrderResponse>> CreatePurchaseOrder(CreatePurchaseOrderRequest request, CancellationToken ct) { var x = await service.CreatePurchaseOrderAsync(request, ct); return CreatedAtAction(nameof(GetPurchaseOrder), new { id = x.Id }, x); }
    [HttpGet("purchase-orders/{id:guid}")] public async Task<ActionResult<PurchaseOrderResponse>> GetPurchaseOrder(Guid id, CancellationToken ct) { var x = await service.GetPurchaseOrderAsync(id, ct); return x is null ? NotFound() : Ok(x); }
    [HttpGet("purchase-orders")] public async Task<ActionResult<IReadOnlyCollection<PurchaseOrderResponse>>> PurchaseOrders([FromQuery] Guid storeId, CancellationToken ct) => Ok(await service.GetPurchaseOrdersAsync(storeId, ct));
    [HttpPost("purchase-orders/{id:guid}/approve")] public async Task<ActionResult<PurchaseOrderResponse>> Approve(Guid id, CancellationToken ct) => Ok(await service.ApprovePurchaseOrderAsync(id, ct));
    [HttpPost("purchase-orders/{id:guid}/receive")] public async Task<ActionResult<GoodsReceiptResponse>> Receive(Guid id, ReceivePurchaseOrderRequest request, CancellationToken ct) => Ok(await service.ReceivePurchaseOrderAsync(id, request, ct));
    [HttpPost("stock-transfers")] public async Task<ActionResult<StockTransferResponse>> CreateTransfer(CreateStockTransferRequest request, CancellationToken ct) { var x = await service.CreateStockTransferAsync(request, ct); return CreatedAtAction(nameof(GetTransfer), new { id = x.Id }, x); }
    [HttpGet("stock-transfers/{id:guid}")] public async Task<ActionResult<StockTransferResponse>> GetTransfer(Guid id, CancellationToken ct) { var x = await service.GetStockTransferAsync(id, ct); return x is null ? NotFound() : Ok(x); }
    [HttpPost("stock-transfers/{id:guid}/dispatch")] public async Task<ActionResult<StockTransferResponse>> Dispatch(Guid id, TransferActionRequest request, CancellationToken ct) => Ok(await service.DispatchStockTransferAsync(id, request.UserId, ct));
    [HttpPost("stock-transfers/{id:guid}/receive")] public async Task<ActionResult<StockTransferResponse>> ReceiveTransfer(Guid id, TransferActionRequest request, CancellationToken ct) => Ok(await service.ReceiveStockTransferAsync(id, request.UserId, ct));
}
