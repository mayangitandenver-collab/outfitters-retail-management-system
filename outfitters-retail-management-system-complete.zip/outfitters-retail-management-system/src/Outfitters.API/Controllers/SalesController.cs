using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Outfitters.Application.Sales;
namespace Outfitters.API.Controllers;
[ApiController, Route("api/sales"), Authorize]
public sealed class SalesController(ISalesService sales, IReceiptPrinter printer) : ControllerBase
{
    [HttpPost("checkout")] public async Task<ActionResult<SaleResponse>> Checkout(CheckoutRequest request, CancellationToken ct) => Ok(await sales.CheckoutAsync(request, ct));
    [HttpGet("{id:guid}")] public async Task<ActionResult<SaleResponse>> Get(Guid id, CancellationToken ct) { var x = await sales.GetSaleAsync(id, ct); return x is null ? NotFound() : Ok(x); }
    [HttpGet] public async Task<ActionResult<IReadOnlyCollection<SaleResponse>>> List([FromQuery] Guid storeId, [FromQuery] DateTime? fromUtc, [FromQuery] DateTime? toUtc, CancellationToken ct) => Ok(await sales.GetSalesAsync(storeId, fromUtc, toUtc, ct));
    [HttpGet("{id:guid}/receipt")] public async Task<IActionResult> Receipt(Guid id, CancellationToken ct) => File(await sales.BuildReceiptAsync(id, ct), "application/octet-stream", $"receipt-{id}.bin");
    [HttpPost("{id:guid}/print")] public async Task<IActionResult> Print(Guid id, ReceiptPrintRequest request, CancellationToken ct) { if (string.IsNullOrWhiteSpace(request.PrinterHost)) return BadRequest("PrinterHost is required."); await printer.PrintAsync(await sales.BuildReceiptAsync(id, ct), request.PrinterHost, request.PrinterPort, request.Copies, ct); return NoContent(); }
}
