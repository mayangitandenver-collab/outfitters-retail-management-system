using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Outfitters.Application.Customers;
namespace Outfitters.API.Controllers;
[ApiController, Route("api/customers"), Authorize]
public sealed class CustomersController(ICustomerService service) : ControllerBase
{
    [HttpGet] public async Task<ActionResult<IReadOnlyCollection<CustomerResponse>>> Search(Guid companyId, string? search, CancellationToken ct) => Ok(await service.SearchAsync(companyId, search, ct));
    [HttpGet("{id:guid}")] public async Task<ActionResult<CustomerResponse>> Get(Guid id, CancellationToken ct) { var x = await service.GetAsync(id, ct); return x is null ? NotFound() : Ok(x); }
    [HttpPost] public async Task<ActionResult<CustomerResponse>> Create(CreateCustomerRequest request, CancellationToken ct) { var x = await service.CreateAsync(request, ct); return CreatedAtAction(nameof(Get), new { id = x.Id }, x); }
    [HttpPut("{id:guid}")] public async Task<ActionResult<CustomerResponse>> Update(Guid id, UpdateCustomerRequest request, CancellationToken ct) => Ok(await service.UpdateAsync(id, request, ct));
    [HttpPost("{id:guid}/loyalty/adjust")] public async Task<ActionResult<LoyaltyTransactionResponse>> Adjust(Guid id, AdjustLoyaltyRequest request, CancellationToken ct) => Ok(await service.AdjustLoyaltyAsync(id, request, ct));
    [HttpGet("{id:guid}/loyalty")] public async Task<ActionResult<IReadOnlyCollection<LoyaltyTransactionResponse>>> Loyalty(Guid id, CancellationToken ct) => Ok(await service.GetLoyaltyHistoryAsync(id, ct));
}
