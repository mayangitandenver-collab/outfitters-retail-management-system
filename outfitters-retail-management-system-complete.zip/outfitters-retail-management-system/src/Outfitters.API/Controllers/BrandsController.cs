using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Outfitters.Application.Catalog;
namespace Outfitters.API.Controllers;
[ApiController, Route("api/brands"), Authorize]
public sealed class BrandsController(ICatalogService service) : ControllerBase
{
    [HttpGet] public async Task<ActionResult<IReadOnlyCollection<BrandResponse>>> Get([FromQuery] Guid companyId, CancellationToken ct) => Ok(await service.GetBrandsAsync(companyId, ct));
    [HttpPost] public async Task<ActionResult<BrandResponse>> Create(CreateBrandRequest request, CancellationToken ct) { var result = await service.CreateBrandAsync(request, ct); return CreatedAtAction(nameof(Get), new { companyId = result.CompanyId }, result); }
}
