using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Outfitters.Application.Auth;
namespace Outfitters.API.Controllers;
[ApiController]
[Route("api/auth")]
public sealed class AuthController(IAuthService auth) : ControllerBase
{
    [AllowAnonymous, HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request, CancellationToken ct)
    {
        var result = await auth.LoginAsync(request, HttpContext.Connection.RemoteIpAddress?.ToString(), ct);
        return result is null ? Unauthorized(new { message = "Invalid username or password." }) : Ok(result);
    }
    [AllowAnonymous, HttpPost("refresh")]
    public async Task<IActionResult> Refresh(RefreshRequest request, CancellationToken ct)
    {
        var result = await auth.RefreshAsync(request, HttpContext.Connection.RemoteIpAddress?.ToString(), ct);
        return result is null ? Unauthorized(new { message = "Invalid or expired refresh token." }) : Ok(result);
    }
    [Authorize, HttpPost("logout")]
    public async Task<IActionResult> Logout(LogoutRequest request, CancellationToken ct) => await auth.LogoutAsync(request, ct) ? NoContent() : NotFound();
}
