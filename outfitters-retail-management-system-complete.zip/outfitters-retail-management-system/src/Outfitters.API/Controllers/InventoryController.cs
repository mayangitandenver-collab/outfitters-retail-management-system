using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Outfitters.Application.Catalog;
namespace Outfitters.API.Controllers;
[ApiController, Route("api/inventory"), Authorize]
public sealed class InventoryController(ICatalogService service) : ControllerBase
{
    [HttpGet] public async Task<ActionResult<IReadOnlyCollection<InventoryResponse>>> Get([FromQuery] Guid storeId, [FromQuery] string? search, [FromQuery] bool lowStockOnly, CancellationToken ct) => Ok(await service.GetInventoryAsync(storeId, search, lowStockOnly, ct));
    [HttpPost("adjust")] public async Task<ActionResult<InventoryResponse>> Adjust(AdjustInventoryRequest request, CancellationToken ct) => Ok(await service.AdjustInventoryAsync(request, ct));
    [HttpPost("transfer")] public async Task<IActionResult> Transfer(TransferInventoryRequest request, CancellationToken ct) { await service.TransferInventoryAsync(request, ct); return NoContent(); }
    [HttpGet("history")] public async Task<ActionResult<IReadOnlyCollection<InventoryTransactionResponse>>> History([FromQuery] Guid storeId, [FromQuery] Guid? variantId, CancellationToken ct) => Ok(await service.GetInventoryHistoryAsync(storeId, variantId, ct));
}
