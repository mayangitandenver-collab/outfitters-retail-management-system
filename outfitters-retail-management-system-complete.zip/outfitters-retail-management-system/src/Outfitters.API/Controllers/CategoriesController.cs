using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Outfitters.Application.Catalog;
namespace Outfitters.API.Controllers;
[ApiController, Route("api/categories"), Authorize]
public sealed class CategoriesController(ICatalogService service) : ControllerBase
{
    [HttpGet] public async Task<ActionResult<IReadOnlyCollection<CategoryResponse>>> Get([FromQuery] Guid companyId, CancellationToken ct) => Ok(await service.GetCategoriesAsync(companyId, ct));
    [HttpPost] public async Task<ActionResult<CategoryResponse>> Create(CreateCategoryRequest request, CancellationToken ct) { var result = await service.CreateCategoryAsync(request, ct); return CreatedAtAction(nameof(Get), new { companyId = result.CompanyId }, result); }
}
