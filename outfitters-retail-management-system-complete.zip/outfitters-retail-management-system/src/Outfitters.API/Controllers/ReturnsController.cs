using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Outfitters.Application.Returns;
namespace Outfitters.API.Controllers;
[ApiController, Route("api/returns"), Authorize]
public sealed class ReturnsController(IReturnService service) : ControllerBase
{
    [HttpPost] public async Task<ActionResult<SaleReturnResponse>> Create(CreateReturnRequest request, CancellationToken ct) { var x = await service.CreateAsync(request, ct); return CreatedAtAction(nameof(Get), new { id = x.Id }, x); }
    [HttpGet("{id:guid}")] public async Task<ActionResult<SaleReturnResponse>> Get(Guid id, CancellationToken ct) { var x = await service.GetAsync(id, ct); return x is null ? NotFound() : Ok(x); }
    [HttpGet] public async Task<ActionResult<IReadOnlyCollection<SaleReturnResponse>>> List(Guid storeId, DateTime? fromUtc, DateTime? toUtc, CancellationToken ct) => Ok(await service.GetByStoreAsync(storeId, fromUtc, toUtc, ct));
}
