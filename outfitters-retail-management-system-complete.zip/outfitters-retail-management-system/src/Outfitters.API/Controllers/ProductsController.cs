using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Outfitters.Application.Catalog;
namespace Outfitters.API.Controllers;
[ApiController, Route("api/products"), Authorize]
public sealed class ProductsController(ICatalogService service) : ControllerBase
{
    [HttpGet] public async Task<ActionResult<IReadOnlyCollection<ProductResponse>>> Get([FromQuery] Guid companyId, [FromQuery] string? search, CancellationToken ct) => Ok(await service.GetProductsAsync(companyId, search, ct));
    [HttpGet("{id:guid}")] public async Task<ActionResult<ProductResponse>> GetById(Guid id, CancellationToken ct) { var result = await service.GetProductAsync(id, ct); return result is null ? NotFound() : Ok(result); }
    [HttpPost] public async Task<ActionResult<ProductResponse>> Create(CreateProductRequest request, CancellationToken ct) { var result = await service.CreateProductAsync(request, ct); return CreatedAtAction(nameof(GetById), new { id = result.Id }, result); }
}
