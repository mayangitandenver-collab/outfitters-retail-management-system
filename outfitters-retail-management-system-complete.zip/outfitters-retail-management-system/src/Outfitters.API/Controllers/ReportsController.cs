using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Outfitters.Application.Reporting;
namespace Outfitters.API.Controllers;
[ApiController, Route("api/reports"), Authorize]
public sealed class ReportsController(IReportingService service) : ControllerBase
{
    [HttpGet("dashboard")] public async Task<ActionResult<DashboardSummaryResponse>> Dashboard(Guid storeId, CancellationToken ct) => Ok(await service.GetDashboardAsync(storeId, ct));
    [HttpGet("monthly-sales")] public async Task<ActionResult<IReadOnlyCollection<MonthlySalesPoint>>> MonthlySales(Guid storeId, int year, CancellationToken ct) => Ok(await service.GetMonthlySalesAsync(storeId, year, ct));
    [HttpGet("top-products")] public async Task<ActionResult<IReadOnlyCollection<TopProductResponse>>> TopProducts(Guid storeId, DateTime fromUtc, DateTime toUtc, int take = 10, CancellationToken ct = default) => Ok(await service.GetTopProductsAsync(storeId, fromUtc, toUtc, take, ct));
    [HttpGet("payments")] public async Task<ActionResult<IReadOnlyCollection<PaymentSummaryResponse>>> Payments(Guid storeId, DateTime fromUtc, DateTime toUtc, CancellationToken ct) => Ok(await service.GetPaymentSummaryAsync(storeId, fromUtc, toUtc, ct));
}
