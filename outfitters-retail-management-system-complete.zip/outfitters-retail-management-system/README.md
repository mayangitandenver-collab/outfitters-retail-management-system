# Outfitters Retail Management System

Sprint 1.1 backend foundation for a multi-store apparel POS and inventory platform.

## Included
- ASP.NET Core 9 Web API
- PostgreSQL + EF Core
- JWT access and refresh tokens
- Company, store, role, permission, user and audit entities
- Seeded first administrator
- Swagger, health checks, Serilog and Docker Compose
- GitHub Actions build/test workflow

## Run with Docker
```bash
docker compose up --build
```
Open Swagger at `http://localhost:8080/swagger`.

Initial local-development credentials:
- Username: `admin`
- Password: `Admin@123`

Change the password and JWT secret before any real deployment.

## Run with the .NET SDK
```bash
dotnet restore
dotnet ef migrations add InitialIdentity --project src/Outfitters.Infrastructure --startup-project src/Outfitters.API
dotnet run --project src/Outfitters.API
```

## Important
This bootstrap uses `EnsureCreated` for the first local database. Before production rollout, generate and commit the baseline EF migration, then replace `EnsureCreatedAsync` with `MigrateAsync`.

## Sprint 1.2 — Apparel catalog and inventory

Added authenticated APIs for categories, brands, products with size/color variants, barcode generation, per-store inventory, stock adjustments, stock transfers, low-stock queries, and inventory transaction history.

Key routes:

- `GET/POST /api/categories`
- `GET/POST /api/brands`
- `GET/POST /api/products`
- `GET /api/products/{id}`
- `GET /api/inventory`
- `POST /api/inventory/adjust`
- `POST /api/inventory/transfer`
- `GET /api/inventory/history`

## Sprint 1.3 POS endpoints

- `POST /api/sales/checkout`
- `GET /api/sales?storeId=...`
- `GET /api/sales/{id}`
- `GET /api/sales/{id}/receipt`
- `POST /api/sales/{id}/print`

Checkout is executed inside a serializable database transaction and deducts inventory atomically.

## Sprint 1.4 additions

- Supplier master data
- Purchase orders and approval
- Partial and full goods receiving
- Automatic inventory posting from receiving
- Two-step stock transfers: draft, dispatch, receipt
- Stock-in-transit audit trail
